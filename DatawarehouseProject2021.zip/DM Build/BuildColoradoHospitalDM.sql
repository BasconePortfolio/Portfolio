-- ColoradoHospitals database developed and written by Nicholas Bascone
-- Peer Reviewed By: Sasha Shadrina
-- Originally Written: 4/17/2021
-- Last updated: 10/10/2021
-- Make the database
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'ColoradoHospital')
	CREATE DATABASE ColoradoHospital
GO
USE ColoradoHospital
GO
-- Create new tables or remake them if already built
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'FactSales'
	)
	DROP TABLE FactSales;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimMedicine'
	)
	DROP TABLE DimMedicine;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimPatient'
	)
	DROP TABLE DimPatient;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimDoctorHospital'
	)
	DROP TABLE DimDoctorHospital;
-- 
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimDate'
	)
	DROP TABLE DimDate;
-- Make the tables
CREATE TABLE DimDate 
	(Date_SK			INT CONSTRAINT pk_date_sk PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10),-- Date in MM-dd-yyyy format
	DayOfMonth			INT, -- Field will hold day number of Month
	DayName				NVARCHAR(9), -- Contains name of the day, Sunday, Monday 
	DayOfWeek			INT,-- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12{}
	MonthName			NVARCHAR(9),-- January, February etc
	MonthOfQuarter		INT,-- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NVARCHAR(9),-- First,Second..
	Year				INT,-- Year value of Date stored in Row
	YearName			CHAR(7), -- CY 2017,CY 2018
	MonthYear			CHAR(10), -- Jan-2018,Feb-2018
	MMYYYY				INT,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsHoliday			BIT,-- Flag 1=National Holiday, 0-No National Holiday
	IsWeekday			BIT,-- 0=Week End ,1=Week Day
	Holiday				NVARCHAR(50),--Name of Holiday in US
	Season				NVARCHAR(10)--Name of Season
	);
--
CREATE TABLE DimDoctorHospital
	(DoctorHospital_SK		INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_doctorhospital_sk PRIMARY KEY,
	DoctorHospital_AK		INT NOT NULL,
	DoctorFirstName			NVARCHAR(25) CONSTRAINT nn_doctor_first_name NOT NULL,
	DoctorLastName			NVARCHAR(30) CONSTRAINT nn_doctor_last_brand NOT NULL,
	DoctorPhoneNumber		NVARCHAR(14) CONSTRAINT nn_doctor_phone_number NOT NULL CONSTRAINT un_doctor_cellphone UNIQUE,
	HospitalName			NVARCHAR(50) CONSTRAINT nn_hospital_name NOT NULL,
	HospitalCityName		NVARCHAR(40) CONSTRAINT nn_hospital_city_name NOT NULL,
	HospitalState			NVARCHAR(2)  CONSTRAINT nn_hospital_state NOT NULL,
	HospitalZIP				NVARCHAR(10) CONSTRAINT nn_hospital_zip NOT NULL,
	StartDate				DATETIME NOT NULL,
	EndDate					DATETIME NULL
	);
--
CREATE TABLE DimPatient
	(Patient_SK			INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_patient_sk PRIMARY KEY,
	Patient_AK			INT NOT NULL,
	DiabetesType		NVARCHAR(50) CONSTRAINT nn_diabetes_type NOT NULL,
	DateBirth			DATE CONSTRAINT nn_date_birth NOT NULL,
	Gender				NVARCHAR(1)	CONSTRAINT nn_gender_identity CHECK ((Gender = 'M') OR (Gender = 'F') OR (Gender = 'I')) NOT NULL,
	Ethnicity			NVARCHAR(25) CONSTRAINT nn_ethnicity NOT NULL,
	PatientCityName		NVARCHAR(40) CONSTRAINT nn_patient_city_name NOT NULL,
	PatientState		NVARCHAR(2)  CONSTRAINT nn_patient_state NOT NULL,
	PatientZIP			NVARCHAR(10) CONSTRAINT nn_patient_zip NOT NULL
	);
--
CREATE TABLE DimMedicine
	(Medicine_SK		INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_medicine_sk PRIMARY KEY,
	Medicine_AK			INT NOT NULL,
	MedicineName		NVARCHAR(50) CONSTRAINT nn_medicine_name NOT NULL,
	MedicineBrand		NVARCHAR(50) CONSTRAINT nn_medicine_brand NOT NULL,
	MedicineDosage		INT CONSTRAINT nn_medicine_dosage NOT NULL
	);
--
CREATE TABLE FactSales
	(SalesOrderID_DD	INT NOT NULL, -- Need a degenerative dimension to create the PK
	Medicine_SK			INT NOT NULL,
	DoctorHospital_SK	INT NOT NULL,
	Patient_SK			INT NOT NULL,
	OrderDateKey		INT NOT NULL,
	OrderPrice			MONEY,
	OrderQuantity		INT,
	OrderDiscount		DECIMAL(2,2),
	CONSTRAINT pk_fact_sales PRIMARY KEY (SalesOrderID_DD),
	CONSTRAINT fk_order_dim_date FOREIGN KEY (OrderDateKey) REFERENCES DimDate(Date_SK),
	CONSTRAINT fk_dim_patient FOREIGN KEY (Patient_SK) REFERENCES DimPatient(Patient_SK),
	CONSTRAINT fk_dim_medicine FOREIGN KEY (Medicine_SK) REFERENCES DimMedicine(Medicine_SK),
	CONSTRAINT fk_dim_doctorhospital FOREIGN KEY (DoctorHospital_SK) REFERENCES DimDoctorHospital(DoctorHospital_SK)
	);
--