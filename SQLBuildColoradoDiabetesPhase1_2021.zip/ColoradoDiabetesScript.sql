-- ColoradoDiabetes database developed and written by Nicholas Bascone
-- Peer Reviewed By: McKayla Sanchez
-- Originally Written: 4/17/2021
-- Last updated: 4/27/2021
------
-- The state of Colorado wants to see what people are making in comparison to how much they are paying for medicine. 
-- The state wants a view of people who have the potential to recieve financial aid from the state for their diabetes medicine.
-- This view is meant to aid in that process.
------
-- Use the ColoradoDiabetes dataset
USE ColoradoDiabetes
GO
-- Use if exists to make sure that if the view already exists it gets deleted to prevent errors.
IF EXISTS (
		SELECT *
		FROM sys.views
		WHERE NAME = N'MedicineAid'
		)
		DROP VIEW MedicineAid;
GO
-- Creating the view with a calculation to get the total cost per month of medicine
-- All the tables are joined to get the results I need below.
CREATE VIEW MedicineAid
AS
	SELECT Patient.PatientFirstName + ' ' + Patient.PatientLastName AS 'Patient Full Name', Patient.PatientPhoneNumber, EconomicClass.EconomicClass, EconomicClassAssign.EconomicClassDescription, EconomicClassAssign.ActualYearlyIncome, Medicine.MedicineName, Medicine.MedicineBrand, Medicine.MedicineDescription, DiabetesType.DiabetesType, Prescription.DatePrescribed, Prescription.PrescriptionCost*Prescription.RefillPerMonth AS 'Total Cost'
	FROM Patient
	INNER JOIN EconomicClassAssign
		ON Patient.PatientID = EconomicClassAssign.PatientID
	INNER JOIN EconomicClass
		ON EconomicClassAssign.EconomicClassID = EconomicClass.EconomicClassID
	INNER JOIN Prescription
		ON Patient.PatientID = Prescription.PatientID
	INNER JOIN Medicine
		ON Prescription.MedicineID = Medicine.MedicineID
	INNER JOIN Diagnosis
		ON Patient.PatientID = Diagnosis.PatientID
	INNER JOIN DiabetesType
		ON Diagnosis.DiabetesTypeID = DiabetesType.DiabetesTypeID
WITH CHECK OPTION;--Check to make sure there's referential integrity
GO
-- Test for MedicineAid View
-- For the test, anyone making less than $40,000 is able to get this money if they pay more than $150 a month for diabetese medication.
SELECT [Patient Full Name], PatientPhoneNumber AS 'Patient Phone Number', '$' + CONVERT(NVARCHAR, CAST(ActualYearlyIncome AS MONEY), 1) AS 'Patient Income', MedicineName AS 'Medicine Name', MedicineBrand AS 'Medicine Brand', MedicineDescription AS 'Medicine Description', DiabetesType AS 'Diabetes Type', '$' + CONVERT(NVARCHAR, CAST([Total Cost] AS MONEY), 1) AS 'Monthly Cost of Medicine'
FROM MedicineAid
WHERE ActualYearlyIncome < 40000 AND [Total Cost] > 150

-- Use if exists to make sure that if the function already exists it gets deleted to prevent errors.
IF EXISTS (
		SELECT *
		FROM sys.objects
		WHERE NAME = N'ufn_DiabetesPatients'
		)
		DROP FUNCTION ufn_DiabetesPatients;
GO
-- Create a function that will take a diabetes type and output the names of all patients with said type of diabetes.
-- The state will use this to see how many people have one type of diabetes and the description to see how the diabetes manafests in the patient.
-- It also displays the area where the residents live so the state can allocate money according to which types of diabetes are where.
-- This will be useful to figure out how much medication they'll need to buy and for what problems.
CREATE FUNCTION dbo.ufn_DiabetesPatients
     (
       @DiabetesType NVARCHAR(20)
      ) 
RETURNS TABLE
AS
RETURN (
  SELECT PatientLastName + ', ' + PatientFirstName AS 'Full Patient Name', Diagnosis.DiagnosisDescription AS 'Diagnosis Description', Patient.PatientCityName AS 'Patient City Name'
  FROM Patient
  INNER JOIN Diagnosis
	ON Patient.PatientID = Diagnosis.PatientID
  INNER JOIN DiabetesType
	ON Diagnosis.DiabetesTypeID = DiabetesType.DiabetesTypeID
  WHERE DiabetesType.DiabetesType = @DiabetesType
  )
GO

-- Test DiabetesPatients 
-- The options are Type1, Type2, Gestational, Insipidus, LADA, MODY, Steroid Induced, Brittle, Secondary, and Double
-- If you don't put in the correct one, you'll get an INVALID column error
-- The state wanted to see how many people were diagnosed with Type 1 Diabetes
-- and wanted to know the cause of the diabetes and where the patient lived.
SELECT [Full Patient Name], [Diagnosis Description], [Patient City Name]
FROM dbo.ufn_DiabetesPatients('Type1');
-- Test if wrong or no input
SELECT [Full Patient Name], [Diagnosis Description], [Patient City Name]
FROM dbo.ufn_DiabetesPatients('');

-- Use if exists to make sure that if the SPROC already exists it gets deleted to prevent errors.
IF EXISTS (
		SELECT *
		FROM sys.objects
		WHERE NAME = N'usp_DoctorPrescription'
		)
		DROP PROCEDURE usp_DoctorPrescription;
GO
-- The state would also like a SPROC where if someone looks up a doctor, they'll get the patient the doctor treated along with their
-- prescription description, date prescribed, the doctor's phone number, the hospital this prescription took place in
-- and the address of the hospital. 
-- This is useful to the state in case they need to audit prescriptions, or learn more about what medicines doctors are prescribing to their patients.
-- The state may also want to reach out to the doctor or hospital which is why their information is included in the table below.
-- For now there should only be one result because each doctor only has one patient.
CREATE PROCEDURE usp_DoctorPrescription (@DoctorFName NVARCHAR(30)=NULL, @DoctorLName NVARCHAR(30)=NULL)  
AS
BEGIN
	DECLARE @DocPrescriptCt INT
	-- Check to see if the sections are filled or not
	IF @DoctorFName IS NOT NULL AND @DoctorLName IS NOT NULL 
		BEGIN
		SELECT @DocPrescriptCt=COUNT(*)
		FROM Doctor
		WHERE Doctor.DoctorFirstName=@DoctorFName AND Doctor.DoctorLastName=@DoctorLName
		-- If they did not put in the right doctor, then they'll get a warning message saying the doctor cannot be found.
		IF @DocPrescriptCt=0
			BEGIN
				SELECT 'The doctor'+' '+@DoctorFName+' '+@DoctorLName+' '+'either does not work in the Colorado Hospital system or has no documented prescriptions, please try again.' AS 'Warning Message'
				RETURN (1)
			END
	-- SELECT to show all my table data
	SELECT Patient.PatientFirstName + ' ' + Patient.PatientLastName AS 'Full Patient Name', DiabetesType.DiabetesType AS 'Diabetes Type', Prescription.PrescriptionDescription AS 'Precription Description', CONVERT(NVARCHAR,Prescription.DatePrescribed,101) AS 'Date Precribed', Doctor.DoctorPhoneNumber AS 'Doctor Phone Number', Hospital.HospitalName AS 'Hospital Name', Hospital.HospitalStreetAddress + ' ' + Hospital.HospitalCityName + ', ' + Hospital.HospitalState + ', ' + Hospital.HospitalZIP AS 'Full Hospital Address'
	FROM Doctor
	INNER JOIN Prescription
		ON Doctor.DoctorID = Prescription.DoctorID
	INNER JOIN Patient
		ON Prescription.PatientID = Patient.PatientID
	INNER JOIN HospitalAssign
		ON Doctor.DoctorID = HospitalAssign.DoctorID
	INNER JOIN Hospital
		ON HospitalAssign.HospitalID = Hospital.HospitalID
	INNER JOIN Diagnosis
		ON Patient.PatientID = Diagnosis.PatientID
	INNER JOIN DiabetesType
		ON Diagnosis.DiabetesTypeID = DiabetesType.DiabetesTypeID
	WHERE Doctor.DoctorFirstName=@DoctorFName AND Doctor.DoctorLastName=@DoctorLName
	ORDER BY Patient.PatientID
	END
ELSE
	-- If nothing was put into the box they get a missing input error
	BEGIN
	SELECT 'Missing Input: The form to use for this procedure is: EXEC DoctorPrescription''<DoctorFirstName>''''<DoctorLastname>''' AS 'Warning Message'
	END
END;
GO
--
-- Test working version
EXEC usp_DoctorPrescription 'Nayma', 'Aktar';
--
-- Test wrong doctor name
EXEC usp_DoctorPrescription 'Nick', 'Bascone';
--
-- Test no inputs
EXEC usp_DoctorPrescription;