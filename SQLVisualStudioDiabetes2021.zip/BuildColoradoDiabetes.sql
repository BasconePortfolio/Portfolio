-- ColoradoDiabetes database developed and written by Nicholas Bascone
-- Peer Reviewed By: McKayla Sanchez
-- Originally Written: 4/17/2021
-- Last updated: 5/15/2021
-----------------------------------------------------------
-- Replace <data_path> with the full path to this file 
-- Ensure it ends with a backslash 
-- E.g., C:\MyDatabases\ See line 20
-----------------------------------------------------------
-- Make the database

IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'ColoradoDiabetes')
	CREATE DATABASE ColoradoDiabetes
GO
USE ColoradoDiabetes

-- Path to get csv data

DECLARE @data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\Nicholas Bascone\OneDrive\Desktop\ColoradoDiabetes\';

-- Delete existing tables to make new ones
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'HospitalAssign'
       )
	DROP TABLE HospitalAssign;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Prescription'
       )
	DROP TABLE Prescription;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'EconomicClassAssign'
       )
	DROP TABLE EconomicClassAssign;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Diagnosis'
       )
	DROP TABLE Diagnosis;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DiabetesType'
       )
	DROP TABLE DiabetesType;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'EconomicClass'
       )
	DROP TABLE EconomicClass;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Patient'
       )
	DROP TABLE Patient;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Medicine'
       )
	DROP TABLE Medicine;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Doctor'
       )
	DROP TABLE Doctor;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Hospital'
       )
	DROP TABLE Hospital;
--
-- Create tables do ones with FKs first then PKs
--
CREATE TABLE DiabetesType
	(DiabetesTypeID		INT CONSTRAINT pk_diabetes_type_id PRIMARY KEY,
	DiabetesType		NVARCHAR(50) CONSTRAINT nn_diabetes_type NOT NULL
	);
--
CREATE TABLE EconomicClass
	(EconomicClassID		INT CONSTRAINT pk_economic_class_id PRIMARY KEY,
	EconomicClass			NVARCHAR(25) CONSTRAINT nn_economic_class NOT NULL,
	YearlyIncomeRange		NVARCHAR(50) CONSTRAINT nn_yearly_income_range NOT NULL
	);
--
CREATE TABLE Patient
	(PatientID				INT CONSTRAINT pk_patient_id PRIMARY KEY,
	PatientFirstName		NVARCHAR(25) CONSTRAINT nn_patient_first_name NOT NULL,
	PatientLastName			NVARCHAR(30) CONSTRAINT nn_patient_last_name NOT NULL,
	DateBirth				DATE CONSTRAINT nn_date_birth NOT NULL,
	PatientPhoneNumber		NVARCHAR(14) CONSTRAINT nn_patient_phone_number NOT NULL CONSTRAINT un_patient_cellphone UNIQUE,
	GenderIdentity			NVARCHAR(1)	CONSTRAINT nn_gender_identity CHECK ((GenderIdentity = 'M') OR (GenderIdentity = 'F') OR (GenderIdentity = 'O')) NOT NULL,
	BirthGender				NVARCHAR(1) CONSTRAINT nn_birth_gender CHECK ((BirthGender = 'M') OR (BirthGender = 'F') OR (BirthGender = 'I')) NOT NULL,
	Ethnicity				NVARCHAR(25) CONSTRAINT nn_ethnicity NOT NULL,
	PatientStreetAddress	NVARCHAR(50) CONSTRAINT nn_patient_street_address NOT NULL,
	PatientCityName			NVARCHAR(40) CONSTRAINT nn_patient_city_name NOT NULL,
	PatientState			NVARCHAR(2)  CONSTRAINT nn_patient_state NOT NULL,
	PatientZIP				NVARCHAR(10) CONSTRAINT nn_patient_zip NOT NULL
	);
--
CREATE TABLE Medicine
	(MedicineID				INT CONSTRAINT pk_medicine_id PRIMARY KEY,
	MedicineName			NVARCHAR(50) CONSTRAINT nn_medicine_name NOT NULL,
	MedicineBrand			NVARCHAR(50) CONSTRAINT nn_medicine_brand NOT NULL,
	MedicineDescription		NVARCHAR(250) CONSTRAINT nn_medicine_description NOT NULL
	);
--
CREATE TABLE Doctor
	(DoctorID				INT CONSTRAINT pk_doctor_id PRIMARY KEY,
	DoctorFirstName			NVARCHAR(25) CONSTRAINT nn_doctor_first_name NOT NULL,
	DoctorLastName			NVARCHAR(30) CONSTRAINT nn_doctor_last_brand NOT NULL,
	DoctorPhoneNumber		NVARCHAR(14) CONSTRAINT nn_doctor_phone_number NOT NULL CONSTRAINT un_doctor_cellphone UNIQUE
	);
--
CREATE TABLE Hospital
	(HospitalID				INT CONSTRAINT pk_hospital_id PRIMARY KEY,
	HospitalName			NVARCHAR(50) CONSTRAINT nn_hospital_name NOT NULL,
	HospitalStreetAddress	NVARCHAR(50) CONSTRAINT nn_hospital_street_address NOT NULL,
	HospitalCityName		NVARCHAR(40) CONSTRAINT nn_hospital_city_name NOT NULL,
	HospitalState			NVARCHAR(2)  CONSTRAINT nn_hospital_state NOT NULL,
	HospitalZIP				NVARCHAR(10) CONSTRAINT nn_hospital_zip NOT NULL
	);
--
CREATE TABLE HospitalAssign
	(HospitalAssignID		INT CONSTRAINT pk_hospital_assign_id PRIMARY KEY,
	DateBegin				DATE CONSTRAINT nn_date_begin NOT NULL,
	DateEnd					DATE,
	HospitalID				INT CONSTRAINT fk_hospital_id FOREIGN KEY 
		REFERENCES Hospital(HospitalID),
	DoctorID				INT CONSTRAINT fk_doctor_hospital_assign_id FOREIGN KEY 
		REFERENCES Doctor(DoctorID)
	);
--
CREATE TABLE Prescription
	(PrescriptionID				INT CONSTRAINT pk_prescription_id PRIMARY KEY,
	PrescriptionDescription		NVARCHAR(250) CONSTRAINT nn_prescription_description NOT NULL,
	PrescriptionCost			MONEY CONSTRAINT nn_prescription_cost NOT NULL,
	RefillPerMonth				NVARCHAR(1) CONSTRAINT nn_refill_per_month NOT NULL,
	MonthlyCost					MONEY CONSTRAINT nn_prescription_cost NOT NULL,
	DatePrescribed				DATE CONSTRAINT nn_date_prescribed NOT NULL,
	MedicineID					INT CONSTRAINT fk_medicine_prescription_id FOREIGN KEY 
		REFERENCES Medicine(MedicineID),
	DoctorID					INT CONSTRAINT fk_doctor_prescription_id FOREIGN KEY 
		REFERENCES Doctor(DoctorID),
	PatientID					INT CONSTRAINT fk_patient_prescription_id FOREIGN KEY 
		REFERENCES Patient(PatientID)
	);
--
CREATE TABLE EconomicClassAssign
	(EconomicClassAssignID		INT CONSTRAINT pk_economic_class_assign_id PRIMARY KEY,
	EconomicClassDescription	NVARCHAR(250) CONSTRAINT nn_economic_class_description NOT NULL,
	ActualYearlyIncome			MONEY CONSTRAINT nn_actual_yearly_income NOT NULL,
	PatientID					INT CONSTRAINT fk_patient_economic_class_assign_id FOREIGN KEY 
		REFERENCES Patient(PatientID),
	EconomicClassID				INT CONSTRAINT fk_economic_class_id FOREIGN KEY 
		REFERENCES EconomicClass(EconomicClassID)
	);
--
CREATE TABLE Diagnosis
	(DiagnosisID			INT CONSTRAINT pk_diagnosis_id PRIMARY KEY,
	DiagnosisDescription	NVARCHAR(250) CONSTRAINT nn_diagnosis_description NOT NULL,
	DateDiagnosed			NVARCHAR(200) CONSTRAINT nn_date_diagnosed NOT NULL,
	PatientID				INT CONSTRAINT fk_patient_diagnosis_id FOREIGN KEY 
		REFERENCES Patient(PatientID),
	DiabetesTypeID			INT CONSTRAINT fk_diabetes_type_id FOREIGN KEY 
		REFERENCES DiabetesType(DiabetesTypeID)
	);
--
-- Load table data from CSV files do PKs first and FKs last
--
EXECUTE (N'BULK INSERT DiabetesType FROM ''' + @data_path + N'DiabetesType.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT EconomicClass FROM ''' + @data_path + N'EconomicClass.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Patient FROM ''' + @data_path + N'Patient.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Medicine FROM ''' + @data_path + N'Medicine.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Doctor FROM ''' + @data_path + N'Doctor.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Hospital FROM ''' + @data_path + N'Hospital.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT HospitalAssign FROM ''' + @data_path + N'HospitalAssign.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Prescription FROM ''' + @data_path + N'Prescription.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT EconomicClassAssign FROM ''' + @data_path + N'EconomicClassAssign.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Diagnosis FROM ''' + @data_path + N'Diagnosis.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= ''\t'',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- List table names and row counts for confirmation
--
GO
SET NOCOUNT ON
SELECT 'DiabetesType' AS "Table",	COUNT(*) AS "Rows"	FROM DiabetesType			UNION
SELECT 'EconomicClass',				COUNT(*)			FROM EconomicClass			UNION
SELECT 'Patient',					COUNT(*)			FROM Patient				UNION
SELECT 'Medicine',					COUNT(*)			FROM Medicine				UNION
SELECT 'Doctor',					COUNT(*)			FROM Doctor					UNION
SELECT 'Hospital',					COUNT(*)			FROM Hospital				UNION
SELECT 'HospitalAssign',			COUNT(*)			FROM HospitalAssign			UNION
SELECT 'Prescription',				COUNT(*)			FROM Prescription			UNION
SELECT 'EconomicClassAssign',		COUNT(*)			FROM EconomicClassAssign	UNION
SELECT 'Diagnosis',					COUNT(*)			FROM Diagnosis
ORDER BY 1;
SET NOCOUNT OFF
GO
