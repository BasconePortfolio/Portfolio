﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EconomicClassDGV
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EconomicClassDGV))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.ColoradoDiabetesDataSet = New ColoradoDiabetesForms.ColoradoDiabetesDataSet()
        Me.EconomicClassAssignBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EconomicClassAssignTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.EconomicClassAssignTableAdapter()
        Me.TableAdapterManager = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager()
        Me.EconomicClassTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.EconomicClassTableAdapter()
        Me.PatientTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter()
        Me.EconomicClassAssignBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EconomicClassAssignBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.EconomicClassAssignDataGridView = New System.Windows.Forms.DataGridView()
        Me.PatientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EconomicClassBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblTitleEC = New System.Windows.Forms.Label()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.EconomicClassAssignIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.EconomicClassAssignIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EconomicClassAssignBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EconomicClassAssignBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EconomicClassAssignBindingNavigator.SuspendLayout()
        CType(Me.EconomicClassAssignDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EconomicClassBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'ColoradoDiabetesDataSet
        '
        Me.ColoradoDiabetesDataSet.DataSetName = "ColoradoDiabetesDataSet"
        Me.ColoradoDiabetesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EconomicClassAssignBindingSource
        '
        Me.EconomicClassAssignBindingSource.DataMember = "EconomicClassAssign"
        Me.EconomicClassAssignBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'EconomicClassAssignTableAdapter
        '
        Me.EconomicClassAssignTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DiabetesTypeTableAdapter = Nothing
        Me.TableAdapterManager.DiagnosisTableAdapter = Nothing
        Me.TableAdapterManager.DoctorTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassAssignTableAdapter = Me.EconomicClassAssignTableAdapter
        Me.TableAdapterManager.EconomicClassTableAdapter = Me.EconomicClassTableAdapter
        Me.TableAdapterManager.HospitalAssignTableAdapter = Nothing
        Me.TableAdapterManager.HospitalTableAdapter = Nothing
        Me.TableAdapterManager.MedicineTableAdapter = Nothing
        Me.TableAdapterManager.PatientTableAdapter = Me.PatientTableAdapter
        Me.TableAdapterManager.PrescriptionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EconomicClassTableAdapter
        '
        Me.EconomicClassTableAdapter.ClearBeforeFill = True
        '
        'PatientTableAdapter
        '
        Me.PatientTableAdapter.ClearBeforeFill = True
        '
        'EconomicClassAssignBindingNavigator
        '
        Me.EconomicClassAssignBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.EconomicClassAssignBindingNavigator.BindingSource = Me.EconomicClassAssignBindingSource
        Me.EconomicClassAssignBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.EconomicClassAssignBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.EconomicClassAssignBindingNavigator.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.EconomicClassAssignBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.EconomicClassAssignBindingNavigatorSaveItem})
        Me.EconomicClassAssignBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.EconomicClassAssignBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.EconomicClassAssignBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.EconomicClassAssignBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.EconomicClassAssignBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.EconomicClassAssignBindingNavigator.Name = "EconomicClassAssignBindingNavigator"
        Me.EconomicClassAssignBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.EconomicClassAssignBindingNavigator.Size = New System.Drawing.Size(2376, 42)
        Me.EconomicClassAssignBindingNavigator.TabIndex = 0
        Me.EconomicClassAssignBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Enabled = False
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(71, 36)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 42)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 39)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 42)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(46, 36)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 42)
        '
        'EconomicClassAssignBindingNavigatorSaveItem
        '
        Me.EconomicClassAssignBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EconomicClassAssignBindingNavigatorSaveItem.Enabled = False
        Me.EconomicClassAssignBindingNavigatorSaveItem.Image = CType(resources.GetObject("EconomicClassAssignBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.EconomicClassAssignBindingNavigatorSaveItem.Name = "EconomicClassAssignBindingNavigatorSaveItem"
        Me.EconomicClassAssignBindingNavigatorSaveItem.Size = New System.Drawing.Size(46, 36)
        Me.EconomicClassAssignBindingNavigatorSaveItem.Text = "Save Data"
        '
        'EconomicClassAssignDataGridView
        '
        Me.EconomicClassAssignDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.EconomicClassAssignDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.EconomicClassAssignDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EconomicClassAssignDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn2})
        Me.EconomicClassAssignDataGridView.DataSource = Me.EconomicClassAssignBindingSource
        Me.EconomicClassAssignDataGridView.Location = New System.Drawing.Point(26, 193)
        Me.EconomicClassAssignDataGridView.Name = "EconomicClassAssignDataGridView"
        Me.EconomicClassAssignDataGridView.RowHeadersWidth = 82
        Me.EconomicClassAssignDataGridView.RowTemplate.Height = 33
        Me.EconomicClassAssignDataGridView.Size = New System.Drawing.Size(2291, 585)
        Me.EconomicClassAssignDataGridView.TabIndex = 1
        '
        'PatientBindingSource
        '
        Me.PatientBindingSource.DataMember = "Patient"
        Me.PatientBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'EconomicClassBindingSource
        '
        Me.EconomicClassBindingSource.DataMember = "EconomicClass"
        Me.EconomicClassBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'lblTitleEC
        '
        Me.lblTitleEC.AutoSize = True
        Me.lblTitleEC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleEC.Location = New System.Drawing.Point(968, 129)
        Me.lblTitleEC.Name = "lblTitleEC"
        Me.lblTitleEC.Size = New System.Drawing.Size(427, 31)
        Me.lblTitleEC.TabIndex = 2
        Me.lblTitleEC.Text = "Economic Class Data Grid View"
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EconomicClassAssignIDToolStripLabel, Me.EconomicClassAssignIDToolStripTextBox, Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 42)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(2376, 42)
        Me.FillByToolStrip.TabIndex = 3
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'EconomicClassAssignIDToolStripLabel
        '
        Me.EconomicClassAssignIDToolStripLabel.Name = "EconomicClassAssignIDToolStripLabel"
        Me.EconomicClassAssignIDToolStripLabel.Size = New System.Drawing.Size(237, 36)
        Me.EconomicClassAssignIDToolStripLabel.Text = "Econ Class Assign ID:"
        '
        'EconomicClassAssignIDToolStripTextBox
        '
        Me.EconomicClassAssignIDToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.EconomicClassAssignIDToolStripTextBox.Name = "EconomicClassAssignIDToolStripTextBox"
        Me.EconomicClassAssignIDToolStripTextBox.Size = New System.Drawing.Size(100, 42)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(90, 36)
        Me.FillByToolStripButton.Text = "Search"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "EconomicClassAssignID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Economic Class Assign ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 60
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "PatientID"
        Me.DataGridViewTextBoxColumn4.DataSource = Me.PatientBindingSource
        Me.DataGridViewTextBoxColumn4.DisplayMember = "PatientFullName"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Patient Name"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn4.ValueMember = "PatientID"
        Me.DataGridViewTextBoxColumn4.Width = 150
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "EconomicClassID"
        Me.DataGridViewTextBoxColumn5.DataSource = Me.EconomicClassBindingSource
        Me.DataGridViewTextBoxColumn5.DisplayMember = "EconomicClass"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Economic Class Category"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn5.ValueMember = "EconomicClassID"
        Me.DataGridViewTextBoxColumn5.Width = 150
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "ActualYearlyIncome"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "C0"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridViewTextBoxColumn3.HeaderText = "Actual Yearly Income"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 80
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "EconomicClassDescription"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Economic Class Description"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 600
        '
        'EconomicClassDGV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(2376, 839)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.lblTitleEC)
        Me.Controls.Add(Me.EconomicClassAssignDataGridView)
        Me.Controls.Add(Me.EconomicClassAssignBindingNavigator)
        Me.Name = "EconomicClassDGV"
        Me.Text = "EconomicClassDGV"
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EconomicClassAssignBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EconomicClassAssignBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EconomicClassAssignBindingNavigator.ResumeLayout(False)
        Me.EconomicClassAssignBindingNavigator.PerformLayout()
        CType(Me.EconomicClassAssignDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EconomicClassBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ColoradoDiabetesDataSet As ColoradoDiabetesDataSet
    Friend WithEvents EconomicClassAssignBindingSource As BindingSource
    Friend WithEvents EconomicClassAssignTableAdapter As ColoradoDiabetesDataSetTableAdapters.EconomicClassAssignTableAdapter
    Friend WithEvents TableAdapterManager As ColoradoDiabetesDataSetTableAdapters.TableAdapterManager
    Friend WithEvents EconomicClassAssignBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents EconomicClassAssignBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents EconomicClassAssignDataGridView As DataGridView
    Friend WithEvents PatientTableAdapter As ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter
    Friend WithEvents lblTitleEC As Label
    Friend WithEvents PatientBindingSource As BindingSource
    Friend WithEvents EconomicClassTableAdapter As ColoradoDiabetesDataSetTableAdapters.EconomicClassTableAdapter
    Friend WithEvents EconomicClassBindingSource As BindingSource
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents EconomicClassAssignIDToolStripLabel As ToolStripLabel
    Friend WithEvents EconomicClassAssignIDToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
End Class
