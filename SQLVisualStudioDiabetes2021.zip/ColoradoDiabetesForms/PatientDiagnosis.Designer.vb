﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientDiagnosis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PatientIDLabel As System.Windows.Forms.Label
        Dim PatientFirstNameLabel As System.Windows.Forms.Label
        Dim PatientLastNameLabel As System.Windows.Forms.Label
        Dim DateBirthLabel As System.Windows.Forms.Label
        Dim PatientPhoneNumberLabel As System.Windows.Forms.Label
        Dim GenderIdentityLabel As System.Windows.Forms.Label
        Dim BirthGenderLabel As System.Windows.Forms.Label
        Dim EthnicityLabel As System.Windows.Forms.Label
        Dim PatientStreetAddressLabel As System.Windows.Forms.Label
        Dim PatientCityNameLabel As System.Windows.Forms.Label
        Dim PatientStateLabel As System.Windows.Forms.Label
        Dim PatientZIPLabel As System.Windows.Forms.Label
        Dim PatientFullNameLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientDiagnosis))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PatientBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.PatientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ColoradoDiabetesDataSet = New ColoradoDiabetesForms.ColoradoDiabetesDataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.PatientBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.PatientIDTextBox = New System.Windows.Forms.TextBox()
        Me.PatientFirstNameTextBox = New System.Windows.Forms.TextBox()
        Me.PatientLastNameTextBox = New System.Windows.Forms.TextBox()
        Me.DateBirthDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.GenderIdentityTextBox = New System.Windows.Forms.TextBox()
        Me.BirthGenderTextBox = New System.Windows.Forms.TextBox()
        Me.EthnicityTextBox = New System.Windows.Forms.TextBox()
        Me.PatientStreetAddressTextBox = New System.Windows.Forms.TextBox()
        Me.PatientCityNameTextBox = New System.Windows.Forms.TextBox()
        Me.PatientStateTextBox = New System.Windows.Forms.TextBox()
        Me.PatientZIPTextBox = New System.Windows.Forms.TextBox()
        Me.PatientFullNameTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.DiagnosisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DiagnosisDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DiabetesTypeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.PatientLastNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.PatientLastNameToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PatientTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter()
        Me.TableAdapterManager = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager()
        Me.DiabetesTypeTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.DiabetesTypeTableAdapter()
        Me.DiagnosisTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.DiagnosisTableAdapter()
        PatientIDLabel = New System.Windows.Forms.Label()
        PatientFirstNameLabel = New System.Windows.Forms.Label()
        PatientLastNameLabel = New System.Windows.Forms.Label()
        DateBirthLabel = New System.Windows.Forms.Label()
        PatientPhoneNumberLabel = New System.Windows.Forms.Label()
        GenderIdentityLabel = New System.Windows.Forms.Label()
        BirthGenderLabel = New System.Windows.Forms.Label()
        EthnicityLabel = New System.Windows.Forms.Label()
        PatientStreetAddressLabel = New System.Windows.Forms.Label()
        PatientCityNameLabel = New System.Windows.Forms.Label()
        PatientStateLabel = New System.Windows.Forms.Label()
        PatientZIPLabel = New System.Windows.Forms.Label()
        PatientFullNameLabel = New System.Windows.Forms.Label()
        CType(Me.PatientBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PatientBindingNavigator.SuspendLayout()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiagnosisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiagnosisDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiabetesTypeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'PatientIDLabel
        '
        PatientIDLabel.AutoSize = True
        PatientIDLabel.Location = New System.Drawing.Point(654, 289)
        PatientIDLabel.Name = "PatientIDLabel"
        PatientIDLabel.Size = New System.Drawing.Size(111, 25)
        PatientIDLabel.TabIndex = 1
        PatientIDLabel.Text = "Patient ID:"
        '
        'PatientFirstNameLabel
        '
        PatientFirstNameLabel.AutoSize = True
        PatientFirstNameLabel.Location = New System.Drawing.Point(654, 326)
        PatientFirstNameLabel.Name = "PatientFirstNameLabel"
        PatientFirstNameLabel.Size = New System.Drawing.Size(195, 25)
        PatientFirstNameLabel.TabIndex = 3
        PatientFirstNameLabel.Text = "Patient First Name:"
        '
        'PatientLastNameLabel
        '
        PatientLastNameLabel.AutoSize = True
        PatientLastNameLabel.Location = New System.Drawing.Point(654, 363)
        PatientLastNameLabel.Name = "PatientLastNameLabel"
        PatientLastNameLabel.Size = New System.Drawing.Size(194, 25)
        PatientLastNameLabel.TabIndex = 5
        PatientLastNameLabel.Text = "Patient Last Name:"
        '
        'DateBirthLabel
        '
        DateBirthLabel.AutoSize = True
        DateBirthLabel.Location = New System.Drawing.Point(654, 437)
        DateBirthLabel.Name = "DateBirthLabel"
        DateBirthLabel.Size = New System.Drawing.Size(113, 25)
        DateBirthLabel.TabIndex = 7
        DateBirthLabel.Text = "Date Birth:"
        '
        'PatientPhoneNumberLabel
        '
        PatientPhoneNumberLabel.AutoSize = True
        PatientPhoneNumberLabel.Location = New System.Drawing.Point(1163, 439)
        PatientPhoneNumberLabel.Name = "PatientPhoneNumberLabel"
        PatientPhoneNumberLabel.Size = New System.Drawing.Size(234, 25)
        PatientPhoneNumberLabel.TabIndex = 9
        PatientPhoneNumberLabel.Text = "Patient Phone Number:"
        '
        'GenderIdentityLabel
        '
        GenderIdentityLabel.AutoSize = True
        GenderIdentityLabel.Location = New System.Drawing.Point(654, 471)
        GenderIdentityLabel.Name = "GenderIdentityLabel"
        GenderIdentityLabel.Size = New System.Drawing.Size(164, 25)
        GenderIdentityLabel.TabIndex = 11
        GenderIdentityLabel.Text = "Gender Identity:"
        '
        'BirthGenderLabel
        '
        BirthGenderLabel.AutoSize = True
        BirthGenderLabel.Location = New System.Drawing.Point(654, 511)
        BirthGenderLabel.Name = "BirthGenderLabel"
        BirthGenderLabel.Size = New System.Drawing.Size(139, 25)
        BirthGenderLabel.TabIndex = 13
        BirthGenderLabel.Text = "Birth Gender:"
        '
        'EthnicityLabel
        '
        EthnicityLabel.AutoSize = True
        EthnicityLabel.Location = New System.Drawing.Point(654, 548)
        EthnicityLabel.Name = "EthnicityLabel"
        EthnicityLabel.Size = New System.Drawing.Size(100, 25)
        EthnicityLabel.TabIndex = 15
        EthnicityLabel.Text = "Ethnicity:"
        '
        'PatientStreetAddressLabel
        '
        PatientStreetAddressLabel.AutoSize = True
        PatientStreetAddressLabel.Location = New System.Drawing.Point(1163, 294)
        PatientStreetAddressLabel.Name = "PatientStreetAddressLabel"
        PatientStreetAddressLabel.Size = New System.Drawing.Size(233, 25)
        PatientStreetAddressLabel.TabIndex = 17
        PatientStreetAddressLabel.Text = "Patient Street Address:"
        '
        'PatientCityNameLabel
        '
        PatientCityNameLabel.AutoSize = True
        PatientCityNameLabel.Location = New System.Drawing.Point(1163, 331)
        PatientCityNameLabel.Name = "PatientCityNameLabel"
        PatientCityNameLabel.Size = New System.Drawing.Size(190, 25)
        PatientCityNameLabel.TabIndex = 19
        PatientCityNameLabel.Text = "Patient City Name:"
        '
        'PatientStateLabel
        '
        PatientStateLabel.AutoSize = True
        PatientStateLabel.Location = New System.Drawing.Point(1163, 368)
        PatientStateLabel.Name = "PatientStateLabel"
        PatientStateLabel.Size = New System.Drawing.Size(141, 25)
        PatientStateLabel.TabIndex = 21
        PatientStateLabel.Text = "Patient State:"
        '
        'PatientZIPLabel
        '
        PatientZIPLabel.AutoSize = True
        PatientZIPLabel.Location = New System.Drawing.Point(1163, 405)
        PatientZIPLabel.Name = "PatientZIPLabel"
        PatientZIPLabel.Size = New System.Drawing.Size(123, 25)
        PatientZIPLabel.TabIndex = 23
        PatientZIPLabel.Text = "Patient ZIP:"
        '
        'PatientFullNameLabel
        '
        PatientFullNameLabel.AutoSize = True
        PatientFullNameLabel.Location = New System.Drawing.Point(654, 399)
        PatientFullNameLabel.Name = "PatientFullNameLabel"
        PatientFullNameLabel.Size = New System.Drawing.Size(188, 25)
        PatientFullNameLabel.TabIndex = 25
        PatientFullNameLabel.Text = "Patient Full Name:"
        '
        'PatientBindingNavigator
        '
        Me.PatientBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.PatientBindingNavigator.BindingSource = Me.PatientBindingSource
        Me.PatientBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.PatientBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.PatientBindingNavigator.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.PatientBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.PatientBindingNavigatorSaveItem})
        Me.PatientBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.PatientBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.PatientBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.PatientBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.PatientBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.PatientBindingNavigator.Name = "PatientBindingNavigator"
        Me.PatientBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.PatientBindingNavigator.Size = New System.Drawing.Size(2385, 50)
        Me.PatientBindingNavigator.TabIndex = 0
        Me.PatientBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Enabled = False
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'PatientBindingSource
        '
        Me.PatientBindingSource.DataMember = "Patient"
        Me.PatientBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'ColoradoDiabetesDataSet
        '
        Me.ColoradoDiabetesDataSet.DataSetName = "ColoradoDiabetesDataSet"
        Me.ColoradoDiabetesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(71, 44)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 50)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 39)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 50)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 50)
        '
        'PatientBindingNavigatorSaveItem
        '
        Me.PatientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PatientBindingNavigatorSaveItem.Enabled = False
        Me.PatientBindingNavigatorSaveItem.Image = CType(resources.GetObject("PatientBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.PatientBindingNavigatorSaveItem.Name = "PatientBindingNavigatorSaveItem"
        Me.PatientBindingNavigatorSaveItem.Size = New System.Drawing.Size(46, 44)
        Me.PatientBindingNavigatorSaveItem.Text = "Save Data"
        '
        'PatientIDTextBox
        '
        Me.PatientIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientID", True))
        Me.PatientIDTextBox.Location = New System.Drawing.Point(894, 286)
        Me.PatientIDTextBox.Name = "PatientIDTextBox"
        Me.PatientIDTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientIDTextBox.TabIndex = 2
        '
        'PatientFirstNameTextBox
        '
        Me.PatientFirstNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientFirstName", True))
        Me.PatientFirstNameTextBox.Location = New System.Drawing.Point(894, 323)
        Me.PatientFirstNameTextBox.Name = "PatientFirstNameTextBox"
        Me.PatientFirstNameTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientFirstNameTextBox.TabIndex = 4
        '
        'PatientLastNameTextBox
        '
        Me.PatientLastNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientLastName", True))
        Me.PatientLastNameTextBox.Location = New System.Drawing.Point(894, 360)
        Me.PatientLastNameTextBox.Name = "PatientLastNameTextBox"
        Me.PatientLastNameTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientLastNameTextBox.TabIndex = 6
        '
        'DateBirthDateTimePicker
        '
        Me.DateBirthDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PatientBindingSource, "DateBirth", True))
        Me.DateBirthDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateBirthDateTimePicker.Location = New System.Drawing.Point(894, 433)
        Me.DateBirthDateTimePicker.Name = "DateBirthDateTimePicker"
        Me.DateBirthDateTimePicker.Size = New System.Drawing.Size(200, 31)
        Me.DateBirthDateTimePicker.TabIndex = 8
        '
        'GenderIdentityTextBox
        '
        Me.GenderIdentityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "GenderIdentity", True))
        Me.GenderIdentityTextBox.Location = New System.Drawing.Point(894, 471)
        Me.GenderIdentityTextBox.Name = "GenderIdentityTextBox"
        Me.GenderIdentityTextBox.Size = New System.Drawing.Size(200, 31)
        Me.GenderIdentityTextBox.TabIndex = 12
        '
        'BirthGenderTextBox
        '
        Me.BirthGenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "BirthGender", True))
        Me.BirthGenderTextBox.Location = New System.Drawing.Point(894, 508)
        Me.BirthGenderTextBox.Name = "BirthGenderTextBox"
        Me.BirthGenderTextBox.Size = New System.Drawing.Size(200, 31)
        Me.BirthGenderTextBox.TabIndex = 14
        '
        'EthnicityTextBox
        '
        Me.EthnicityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "Ethnicity", True))
        Me.EthnicityTextBox.Location = New System.Drawing.Point(894, 545)
        Me.EthnicityTextBox.Name = "EthnicityTextBox"
        Me.EthnicityTextBox.Size = New System.Drawing.Size(200, 31)
        Me.EthnicityTextBox.TabIndex = 16
        '
        'PatientStreetAddressTextBox
        '
        Me.PatientStreetAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientStreetAddress", True))
        Me.PatientStreetAddressTextBox.Location = New System.Drawing.Point(1403, 291)
        Me.PatientStreetAddressTextBox.Name = "PatientStreetAddressTextBox"
        Me.PatientStreetAddressTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientStreetAddressTextBox.TabIndex = 18
        '
        'PatientCityNameTextBox
        '
        Me.PatientCityNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientCityName", True))
        Me.PatientCityNameTextBox.Location = New System.Drawing.Point(1403, 328)
        Me.PatientCityNameTextBox.Name = "PatientCityNameTextBox"
        Me.PatientCityNameTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientCityNameTextBox.TabIndex = 20
        '
        'PatientStateTextBox
        '
        Me.PatientStateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientState", True))
        Me.PatientStateTextBox.Location = New System.Drawing.Point(1403, 365)
        Me.PatientStateTextBox.Name = "PatientStateTextBox"
        Me.PatientStateTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientStateTextBox.TabIndex = 22
        '
        'PatientZIPTextBox
        '
        Me.PatientZIPTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientZIP", True))
        Me.PatientZIPTextBox.Location = New System.Drawing.Point(1403, 402)
        Me.PatientZIPTextBox.Name = "PatientZIPTextBox"
        Me.PatientZIPTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientZIPTextBox.TabIndex = 24
        '
        'PatientFullNameTextBox
        '
        Me.PatientFullNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientFullName", True))
        Me.PatientFullNameTextBox.Location = New System.Drawing.Point(894, 396)
        Me.PatientFullNameTextBox.Name = "PatientFullNameTextBox"
        Me.PatientFullNameTextBox.Size = New System.Drawing.Size(200, 31)
        Me.PatientFullNameTextBox.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(973, 148)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(360, 31)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Patient Diagnosis Subform"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(654, 243)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(287, 25)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Patient Demographic Data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(1168, 243)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(298, 25)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Patient Contact Information"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ColoradoDiabetesForms.My.Resources.Resources.COFlag
        Me.PictureBox1.Location = New System.Drawing.Point(1489, 128)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(245, 139)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 30
        Me.PictureBox1.TabStop = False
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PatientBindingSource, "PatientPhoneNumber", True))
        Me.MaskedTextBox1.Location = New System.Drawing.Point(1403, 439)
        Me.MaskedTextBox1.Mask = "(999) 000-0000"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(200, 31)
        Me.MaskedTextBox1.TabIndex = 31
        '
        'DiagnosisBindingSource
        '
        Me.DiagnosisBindingSource.DataMember = "fk_patient_diagnosis_id"
        Me.DiagnosisBindingSource.DataSource = Me.PatientBindingSource
        '
        'DiagnosisDataGridView
        '
        Me.DiagnosisDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DiagnosisDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DiagnosisDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DiagnosisDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn2})
        Me.DiagnosisDataGridView.DataSource = Me.DiagnosisBindingSource
        Me.DiagnosisDataGridView.Location = New System.Drawing.Point(37, 598)
        Me.DiagnosisDataGridView.Name = "DiagnosisDataGridView"
        Me.DiagnosisDataGridView.RowHeadersWidth = 82
        Me.DiagnosisDataGridView.RowTemplate.Height = 33
        Me.DiagnosisDataGridView.Size = New System.Drawing.Size(2292, 220)
        Me.DiagnosisDataGridView.TabIndex = 31
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "DiagnosisID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Diagnosis ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 70
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "DiabetesTypeID"
        Me.DataGridViewTextBoxColumn5.DataSource = Me.DiabetesTypeBindingSource
        Me.DataGridViewTextBoxColumn5.DisplayMember = "DiabetesType"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Diabetes Type"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn5.ValueMember = "DiabetesTypeID"
        Me.DataGridViewTextBoxColumn5.Width = 150
        '
        'DiabetesTypeBindingSource
        '
        Me.DiabetesTypeBindingSource.DataMember = "DiabetesType"
        Me.DiabetesTypeBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "DateDiagnosed"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Date Diagnosed"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 70
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "DiagnosisDescription"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn2.HeaderText = "Diagnosis Description"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 750
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatientLastNameToolStripLabel, Me.PatientLastNameToolStripTextBox, Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 50)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(2385, 50)
        Me.FillByToolStrip.TabIndex = 32
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'PatientLastNameToolStripLabel
        '
        Me.PatientLastNameToolStripLabel.Name = "PatientLastNameToolStripLabel"
        Me.PatientLastNameToolStripLabel.Size = New System.Drawing.Size(212, 44)
        Me.PatientLastNameToolStripLabel.Text = "Patient Last Name:"
        '
        'PatientLastNameToolStripTextBox
        '
        Me.PatientLastNameToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.PatientLastNameToolStripTextBox.Name = "PatientLastNameToolStripTextBox"
        Me.PatientLastNameToolStripTextBox.Size = New System.Drawing.Size(100, 50)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(90, 44)
        Me.FillByToolStripButton.Text = "Search"
        '
        'PatientTableAdapter
        '
        Me.PatientTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DiabetesTypeTableAdapter = Me.DiabetesTypeTableAdapter
        Me.TableAdapterManager.DiagnosisTableAdapter = Me.DiagnosisTableAdapter
        Me.TableAdapterManager.DoctorTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassAssignTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassTableAdapter = Nothing
        Me.TableAdapterManager.HospitalAssignTableAdapter = Nothing
        Me.TableAdapterManager.HospitalTableAdapter = Nothing
        Me.TableAdapterManager.MedicineTableAdapter = Nothing
        Me.TableAdapterManager.PatientTableAdapter = Me.PatientTableAdapter
        Me.TableAdapterManager.PrescriptionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'DiabetesTypeTableAdapter
        '
        Me.DiabetesTypeTableAdapter.ClearBeforeFill = True
        '
        'DiagnosisTableAdapter
        '
        Me.DiagnosisTableAdapter.ClearBeforeFill = True
        '
        'PatientDiagnosis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(2385, 860)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.DiagnosisDataGridView)
        Me.Controls.Add(Me.MaskedTextBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(PatientIDLabel)
        Me.Controls.Add(Me.PatientIDTextBox)
        Me.Controls.Add(PatientFirstNameLabel)
        Me.Controls.Add(Me.PatientFirstNameTextBox)
        Me.Controls.Add(PatientLastNameLabel)
        Me.Controls.Add(Me.PatientLastNameTextBox)
        Me.Controls.Add(DateBirthLabel)
        Me.Controls.Add(Me.DateBirthDateTimePicker)
        Me.Controls.Add(PatientPhoneNumberLabel)
        Me.Controls.Add(GenderIdentityLabel)
        Me.Controls.Add(Me.GenderIdentityTextBox)
        Me.Controls.Add(BirthGenderLabel)
        Me.Controls.Add(Me.BirthGenderTextBox)
        Me.Controls.Add(EthnicityLabel)
        Me.Controls.Add(Me.EthnicityTextBox)
        Me.Controls.Add(PatientStreetAddressLabel)
        Me.Controls.Add(Me.PatientStreetAddressTextBox)
        Me.Controls.Add(PatientCityNameLabel)
        Me.Controls.Add(Me.PatientCityNameTextBox)
        Me.Controls.Add(PatientStateLabel)
        Me.Controls.Add(Me.PatientStateTextBox)
        Me.Controls.Add(PatientZIPLabel)
        Me.Controls.Add(Me.PatientZIPTextBox)
        Me.Controls.Add(PatientFullNameLabel)
        Me.Controls.Add(Me.PatientFullNameTextBox)
        Me.Controls.Add(Me.PatientBindingNavigator)
        Me.Name = "PatientDiagnosis"
        Me.Text = "PatientDiagnosis"
        CType(Me.PatientBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PatientBindingNavigator.ResumeLayout(False)
        Me.PatientBindingNavigator.PerformLayout()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiagnosisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiagnosisDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiabetesTypeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ColoradoDiabetesDataSet As ColoradoDiabetesDataSet
    Friend WithEvents PatientBindingSource As BindingSource
    Friend WithEvents PatientTableAdapter As ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter
    Friend WithEvents TableAdapterManager As ColoradoDiabetesDataSetTableAdapters.TableAdapterManager
    Friend WithEvents PatientBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents PatientBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents PatientIDTextBox As TextBox
    Friend WithEvents PatientFirstNameTextBox As TextBox
    Friend WithEvents PatientLastNameTextBox As TextBox
    Friend WithEvents DateBirthDateTimePicker As DateTimePicker
    Friend WithEvents GenderIdentityTextBox As TextBox
    Friend WithEvents BirthGenderTextBox As TextBox
    Friend WithEvents EthnicityTextBox As TextBox
    Friend WithEvents PatientStreetAddressTextBox As TextBox
    Friend WithEvents PatientCityNameTextBox As TextBox
    Friend WithEvents PatientStateTextBox As TextBox
    Friend WithEvents PatientZIPTextBox As TextBox
    Friend WithEvents PatientFullNameTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MaskedTextBox1 As MaskedTextBox
    Friend WithEvents DiagnosisTableAdapter As ColoradoDiabetesDataSetTableAdapters.DiagnosisTableAdapter
    Friend WithEvents DiagnosisBindingSource As BindingSource
    Friend WithEvents DiagnosisDataGridView As DataGridView
    Friend WithEvents DiabetesTypeTableAdapter As ColoradoDiabetesDataSetTableAdapters.DiabetesTypeTableAdapter
    Friend WithEvents DiabetesTypeBindingSource As BindingSource
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents PatientLastNameToolStripLabel As ToolStripLabel
    Friend WithEvents PatientLastNameToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
End Class
