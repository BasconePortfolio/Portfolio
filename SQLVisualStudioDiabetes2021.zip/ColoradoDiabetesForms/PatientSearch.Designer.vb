﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpBegDate = New System.Windows.Forms.DateTimePicker()
        Me.dtpEndDate = New System.Windows.Forms.DateTimePicker()
        Me.cboCity = New System.Windows.Forms.ComboBox()
        Me.PatientCityBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ColoradoDiabetesDataSet = New ColoradoDiabetesForms.ColoradoDiabetesDataSet()
        Me.PatientCityTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientCityTableAdapter()
        Me.cboDiabetesType = New System.Windows.Forms.ComboBox()
        Me.DiabetesTypeDistinctBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DiabetesTypeDistinctTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.DiabetesTypeDistinctTableAdapter()
        Me.PatientDiabetesCostBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PatientDiabetesCostTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientDiabetesCostTableAdapter()
        Me.TableAdapterManager = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager()
        Me.PatientDiabetesCostDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MonthlyCost = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblSumPatients = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblCountPatients = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblAvgPrice = New System.Windows.Forms.Label()
        CType(Me.PatientCityBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiabetesTypeDistinctBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientDiabetesCostBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientDiabetesCostDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(660, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(283, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Patient Search"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(273, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(313, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Beginning Prescription Date:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(305, 231)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(281, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Ending Prescription Date:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(929, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(141, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Patient City:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(818, 231)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(252, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Patient Diabetes Type:"
        '
        'dtpBegDate
        '
        Me.dtpBegDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpBegDate.Location = New System.Drawing.Point(603, 153)
        Me.dtpBegDate.Name = "dtpBegDate"
        Me.dtpBegDate.Size = New System.Drawing.Size(200, 31)
        Me.dtpBegDate.TabIndex = 5
        Me.dtpBegDate.Value = New Date(2016, 11, 23, 0, 0, 0, 0)
        '
        'dtpEndDate
        '
        Me.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpEndDate.Location = New System.Drawing.Point(603, 231)
        Me.dtpEndDate.Name = "dtpEndDate"
        Me.dtpEndDate.Size = New System.Drawing.Size(200, 31)
        Me.dtpEndDate.TabIndex = 6
        Me.dtpEndDate.Value = New Date(2020, 12, 23, 0, 0, 0, 0)
        '
        'cboCity
        '
        Me.cboCity.DataSource = Me.PatientCityBindingSource
        Me.cboCity.DisplayMember = "PatientCityName"
        Me.cboCity.FormattingEnabled = True
        Me.cboCity.Location = New System.Drawing.Point(1086, 153)
        Me.cboCity.Name = "cboCity"
        Me.cboCity.Size = New System.Drawing.Size(192, 33)
        Me.cboCity.TabIndex = 7
        Me.cboCity.ValueMember = "PatientCityName"
        '
        'PatientCityBindingSource
        '
        Me.PatientCityBindingSource.DataMember = "PatientCity"
        Me.PatientCityBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'ColoradoDiabetesDataSet
        '
        Me.ColoradoDiabetesDataSet.DataSetName = "ColoradoDiabetesDataSet"
        Me.ColoradoDiabetesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PatientCityTableAdapter
        '
        Me.PatientCityTableAdapter.ClearBeforeFill = True
        '
        'cboDiabetesType
        '
        Me.cboDiabetesType.DataSource = Me.DiabetesTypeDistinctBindingSource
        Me.cboDiabetesType.DisplayMember = "DiabetesType"
        Me.cboDiabetesType.FormattingEnabled = True
        Me.cboDiabetesType.Location = New System.Drawing.Point(1086, 231)
        Me.cboDiabetesType.Name = "cboDiabetesType"
        Me.cboDiabetesType.Size = New System.Drawing.Size(192, 33)
        Me.cboDiabetesType.TabIndex = 8
        Me.cboDiabetesType.ValueMember = "DiabetesType"
        '
        'DiabetesTypeDistinctBindingSource
        '
        Me.DiabetesTypeDistinctBindingSource.DataMember = "DiabetesTypeDistinct"
        Me.DiabetesTypeDistinctBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'DiabetesTypeDistinctTableAdapter
        '
        Me.DiabetesTypeDistinctTableAdapter.ClearBeforeFill = True
        '
        'PatientDiabetesCostBindingSource
        '
        Me.PatientDiabetesCostBindingSource.DataMember = "PatientDiabetesCost"
        Me.PatientDiabetesCostBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'PatientDiabetesCostTableAdapter
        '
        Me.PatientDiabetesCostTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Connection = Nothing
        Me.TableAdapterManager.DiabetesTypeTableAdapter = Nothing
        Me.TableAdapterManager.DiagnosisTableAdapter = Nothing
        Me.TableAdapterManager.DoctorTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassAssignTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassTableAdapter = Nothing
        Me.TableAdapterManager.HospitalAssignTableAdapter = Nothing
        Me.TableAdapterManager.HospitalTableAdapter = Nothing
        Me.TableAdapterManager.MedicineTableAdapter = Nothing
        Me.TableAdapterManager.PatientTableAdapter = Nothing
        Me.TableAdapterManager.PrescriptionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'PatientDiabetesCostDataGridView
        '
        Me.PatientDiabetesCostDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PatientDiabetesCostDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.PatientDiabetesCostDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PatientDiabetesCostDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.MonthlyCost})
        Me.PatientDiabetesCostDataGridView.DataSource = Me.PatientDiabetesCostBindingSource
        Me.PatientDiabetesCostDataGridView.Location = New System.Drawing.Point(51, 352)
        Me.PatientDiabetesCostDataGridView.Name = "PatientDiabetesCostDataGridView"
        Me.PatientDiabetesCostDataGridView.RowHeadersWidth = 82
        Me.PatientDiabetesCostDataGridView.RowTemplate.Height = 33
        Me.PatientDiabetesCostDataGridView.Size = New System.Drawing.Size(1449, 367)
        Me.PatientDiabetesCostDataGridView.TabIndex = 9
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "PatientLastName"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Patient Last Name"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 75
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "PatientFirstName"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Patient First Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 75
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "DiabetesType"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Diabetes Type"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 90
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "PatientCityName"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Patient City Name"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 90
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "MedicineName"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Medicine Name"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 140
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "DatePrescribed"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Date Prescribed"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 10
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 90
        '
        'MonthlyCost
        '
        Me.MonthlyCost.DataPropertyName = "MonthlyCost"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "C0"
        DataGridViewCellStyle8.NullValue = Nothing
        Me.MonthlyCost.DefaultCellStyle = DataGridViewCellStyle8
        Me.MonthlyCost.HeaderText = "Monthly Cost"
        Me.MonthlyCost.MinimumWidth = 10
        Me.MonthlyCost.Name = "MonthlyCost"
        Me.MonthlyCost.Width = 70
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ColoradoDiabetesForms.My.Resources.Resources.COFlag
        Me.PictureBox1.Location = New System.Drawing.Point(994, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(169, 93)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(1086, 286)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(114, 43)
        Me.btnSearch.TabIndex = 11
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(1229, 742)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(222, 25)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Medicine Cost Sum:"
        '
        'lblSumPatients
        '
        Me.lblSumPatients.AutoSize = True
        Me.lblSumPatients.Location = New System.Drawing.Point(1476, 742)
        Me.lblSumPatients.Name = "lblSumPatients"
        Me.lblSumPatients.Size = New System.Drawing.Size(24, 25)
        Me.lblSumPatients.TabIndex = 13
        Me.lblSumPatients.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(1289, 781)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(162, 25)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Patient Count:"
        '
        'lblCountPatients
        '
        Me.lblCountPatients.AutoSize = True
        Me.lblCountPatients.Location = New System.Drawing.Point(1476, 781)
        Me.lblCountPatients.Name = "lblCountPatients"
        Me.lblCountPatients.Size = New System.Drawing.Size(24, 25)
        Me.lblCountPatients.TabIndex = 15
        Me.lblCountPatients.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(974, 816)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(477, 25)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "Average Monthly Medicine Cost Per Patient:"
        '
        'lblAvgPrice
        '
        Me.lblAvgPrice.AutoSize = True
        Me.lblAvgPrice.Location = New System.Drawing.Point(1476, 816)
        Me.lblAvgPrice.Name = "lblAvgPrice"
        Me.lblAvgPrice.Size = New System.Drawing.Size(24, 25)
        Me.lblAvgPrice.TabIndex = 17
        Me.lblAvgPrice.Text = "0"
        '
        'PatientSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(1561, 872)
        Me.Controls.Add(Me.lblAvgPrice)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lblCountPatients)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblSumPatients)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PatientDiabetesCostDataGridView)
        Me.Controls.Add(Me.cboDiabetesType)
        Me.Controls.Add(Me.cboCity)
        Me.Controls.Add(Me.dtpEndDate)
        Me.Controls.Add(Me.dtpBegDate)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PatientSearch"
        Me.Text = "PatientSearch"
        CType(Me.PatientCityBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiabetesTypeDistinctBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientDiabetesCostBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientDiabetesCostDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents dtpBegDate As DateTimePicker
    Friend WithEvents dtpEndDate As DateTimePicker
    Friend WithEvents cboCity As ComboBox
    Friend WithEvents ColoradoDiabetesDataSet As ColoradoDiabetesDataSet
    Friend WithEvents PatientCityBindingSource As BindingSource
    Friend WithEvents PatientCityTableAdapter As ColoradoDiabetesDataSetTableAdapters.PatientCityTableAdapter
    Friend WithEvents cboDiabetesType As ComboBox
    Friend WithEvents DiabetesTypeDistinctBindingSource As BindingSource
    Friend WithEvents DiabetesTypeDistinctTableAdapter As ColoradoDiabetesDataSetTableAdapters.DiabetesTypeDistinctTableAdapter
    Friend WithEvents PatientDiabetesCostBindingSource As BindingSource
    Friend WithEvents PatientDiabetesCostTableAdapter As ColoradoDiabetesDataSetTableAdapters.PatientDiabetesCostTableAdapter
    Friend WithEvents TableAdapterManager As ColoradoDiabetesDataSetTableAdapters.TableAdapterManager
    Friend WithEvents PatientDiabetesCostDataGridView As DataGridView
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents lblSumPatients As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblCountPatients As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblAvgPrice As Label
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents MonthlyCost As DataGridViewTextBoxColumn
End Class
