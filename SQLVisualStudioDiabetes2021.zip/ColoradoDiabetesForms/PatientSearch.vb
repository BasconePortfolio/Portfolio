﻿Public Class PatientSearch
    Private Sub PatientSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.PatientDiabetesCost' table. You can move, or remove it, as needed.
        'Me.PatientDiabetesCostTableAdapter.Fill(Me.ColoradoDiabetesDataSet.PatientDiabetesCost)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.DiabetesTypeDistinct' table. You can move, or remove it, as needed.
        Me.DiabetesTypeDistinctTableAdapter.Fill(Me.ColoradoDiabetesDataSet.DiabetesTypeDistinct)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.PatientCity' table. You can move, or remove it, as needed.
        Me.PatientCityTableAdapter.Fill(Me.ColoradoDiabetesDataSet.PatientCity)

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            Me.PatientDiabetesCostTableAdapter.FillBy(
            Me.ColoradoDiabetesDataSet.PatientDiabetesCost,
            Me.cboCity.SelectedValue,
            Me.cboDiabetesType.SelectedValue,
            Me.dtpBegDate.Value,
            Me.dtpEndDate.Value)
            PatientsCalcs()
        Catch ex As Exception
            MsgBox(ex.Message, , "Error in the Query")
        End Try
        Dim n As Integer
        n = Me.PatientDiabetesCostDataGridView.Rows.Count - 1
        If n = 0 Then
            MsgBox("No listings found!")
        End If
    End Sub
    Private Sub PatientsCalcs()
        Dim sum As Decimal
        Dim dgvr As System.Windows.Forms.DataGridViewRow
        For Each dgvr In Me.PatientDiabetesCostDataGridView.Rows
            sum += dgvr.Cells("MonthlyCost").Value
        Next dgvr
        lblSumPatients.Text = sum.ToString("$ #,##0")

        Dim count As Integer
        count = Me.PatientDiabetesCostDataGridView.Rows.Count - 1
        lblCountPatients.Text = count.ToString

        Dim avg As Decimal
        If (count > 0) Then
            avg = sum / count
        Else
            avg = 0
        End If
        lblAvgPrice.Text = avg.ToString("$ #,##0")
    End Sub

End Class