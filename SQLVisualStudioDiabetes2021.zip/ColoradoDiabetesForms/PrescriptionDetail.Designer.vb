﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrescriptionDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PrescriptionIDLabel As System.Windows.Forms.Label
        Dim PrescriptionDescriptionLabel As System.Windows.Forms.Label
        Dim PrescriptionCostLabel As System.Windows.Forms.Label
        Dim RefillPerMonthLabel As System.Windows.Forms.Label
        Dim MonthlyCostLabel As System.Windows.Forms.Label
        Dim DatePrescribedLabel As System.Windows.Forms.Label
        Dim MedicineIDLabel As System.Windows.Forms.Label
        Dim DoctorIDLabel As System.Windows.Forms.Label
        Dim PatientIDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PrescriptionDetail))
        Me.ColoradoDiabetesDataSet = New ColoradoDiabetesForms.ColoradoDiabetesDataSet()
        Me.PrescriptionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PrescriptionTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PrescriptionTableAdapter()
        Me.TableAdapterManager = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager()
        Me.DoctorTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.DoctorTableAdapter()
        Me.MedicineTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.MedicineTableAdapter()
        Me.PrescriptionBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrescriptionBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.PrescriptionIDTextBox = New System.Windows.Forms.TextBox()
        Me.PrescriptionDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.RefillPerMonthTextBox = New System.Windows.Forms.TextBox()
        Me.DatePrescribedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.MedicineIDComboBox = New System.Windows.Forms.ComboBox()
        Me.MedicineBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DoctorIDComboBox = New System.Windows.Forms.ComboBox()
        Me.DoctorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PatientIDComboBox = New System.Windows.Forms.ComboBox()
        Me.PatientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblDiscount = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PatientTableAdapter = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter()
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.DiscountTextBox = New System.Windows.Forms.TextBox()
        Me.MonthlyCostTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.PrescriptionIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.PrescriptionIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.lblTitlePreDet = New System.Windows.Forms.Label()
        Me.PatientTableAdapter1 = New ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter()
        PrescriptionIDLabel = New System.Windows.Forms.Label()
        PrescriptionDescriptionLabel = New System.Windows.Forms.Label()
        PrescriptionCostLabel = New System.Windows.Forms.Label()
        RefillPerMonthLabel = New System.Windows.Forms.Label()
        MonthlyCostLabel = New System.Windows.Forms.Label()
        DatePrescribedLabel = New System.Windows.Forms.Label()
        MedicineIDLabel = New System.Windows.Forms.Label()
        DoctorIDLabel = New System.Windows.Forms.Label()
        PatientIDLabel = New System.Windows.Forms.Label()
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrescriptionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrescriptionBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PrescriptionBindingNavigator.SuspendLayout()
        CType(Me.MedicineBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'PrescriptionIDLabel
        '
        PrescriptionIDLabel.AutoSize = True
        PrescriptionIDLabel.Location = New System.Drawing.Point(86, 171)
        PrescriptionIDLabel.Name = "PrescriptionIDLabel"
        PrescriptionIDLabel.Size = New System.Drawing.Size(158, 25)
        PrescriptionIDLabel.TabIndex = 1
        PrescriptionIDLabel.Text = "Prescription ID:"
        '
        'PrescriptionDescriptionLabel
        '
        PrescriptionDescriptionLabel.AutoSize = True
        PrescriptionDescriptionLabel.Location = New System.Drawing.Point(86, 208)
        PrescriptionDescriptionLabel.Name = "PrescriptionDescriptionLabel"
        PrescriptionDescriptionLabel.Size = New System.Drawing.Size(246, 25)
        PrescriptionDescriptionLabel.TabIndex = 3
        PrescriptionDescriptionLabel.Text = "Prescription Description:"
        '
        'PrescriptionCostLabel
        '
        PrescriptionCostLabel.AutoSize = True
        PrescriptionCostLabel.Location = New System.Drawing.Point(86, 309)
        PrescriptionCostLabel.Name = "PrescriptionCostLabel"
        PrescriptionCostLabel.Size = New System.Drawing.Size(182, 25)
        PrescriptionCostLabel.TabIndex = 5
        PrescriptionCostLabel.Text = "Prescription Cost:"
        '
        'RefillPerMonthLabel
        '
        RefillPerMonthLabel.AutoSize = True
        RefillPerMonthLabel.Location = New System.Drawing.Point(86, 346)
        RefillPerMonthLabel.Name = "RefillPerMonthLabel"
        RefillPerMonthLabel.Size = New System.Drawing.Size(171, 25)
        RefillPerMonthLabel.TabIndex = 7
        RefillPerMonthLabel.Text = "Refill Per Month:"
        '
        'MonthlyCostLabel
        '
        MonthlyCostLabel.AutoSize = True
        MonthlyCostLabel.Location = New System.Drawing.Point(86, 383)
        MonthlyCostLabel.Name = "MonthlyCostLabel"
        MonthlyCostLabel.Size = New System.Drawing.Size(144, 25)
        MonthlyCostLabel.TabIndex = 9
        MonthlyCostLabel.Text = "Monthly Cost:"
        '
        'DatePrescribedLabel
        '
        DatePrescribedLabel.AutoSize = True
        DatePrescribedLabel.Location = New System.Drawing.Point(86, 421)
        DatePrescribedLabel.Name = "DatePrescribedLabel"
        DatePrescribedLabel.Size = New System.Drawing.Size(172, 25)
        DatePrescribedLabel.TabIndex = 11
        DatePrescribedLabel.Text = "Date Prescribed:"
        '
        'MedicineIDLabel
        '
        MedicineIDLabel.AutoSize = True
        MedicineIDLabel.Location = New System.Drawing.Point(86, 457)
        MedicineIDLabel.Name = "MedicineIDLabel"
        MedicineIDLabel.Size = New System.Drawing.Size(167, 25)
        MedicineIDLabel.TabIndex = 13
        MedicineIDLabel.Text = "Medicine Name:"
        '
        'DoctorIDLabel
        '
        DoctorIDLabel.AutoSize = True
        DoctorIDLabel.Location = New System.Drawing.Point(86, 496)
        DoctorIDLabel.Name = "DoctorIDLabel"
        DoctorIDLabel.Size = New System.Drawing.Size(143, 25)
        DoctorIDLabel.TabIndex = 15
        DoctorIDLabel.Text = "Doctor Name:"
        '
        'PatientIDLabel
        '
        PatientIDLabel.AutoSize = True
        PatientIDLabel.Location = New System.Drawing.Point(86, 535)
        PatientIDLabel.Name = "PatientIDLabel"
        PatientIDLabel.Size = New System.Drawing.Size(147, 25)
        PatientIDLabel.TabIndex = 17
        PatientIDLabel.Text = "Patient Name:"
        '
        'ColoradoDiabetesDataSet
        '
        Me.ColoradoDiabetesDataSet.DataSetName = "ColoradoDiabetesDataSet"
        Me.ColoradoDiabetesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PrescriptionBindingSource
        '
        Me.PrescriptionBindingSource.DataMember = "Prescription"
        Me.PrescriptionBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'PrescriptionTableAdapter
        '
        Me.PrescriptionTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DiabetesTypeTableAdapter = Nothing
        Me.TableAdapterManager.DiagnosisTableAdapter = Nothing
        Me.TableAdapterManager.DoctorTableAdapter = Me.DoctorTableAdapter
        Me.TableAdapterManager.EconomicClassAssignTableAdapter = Nothing
        Me.TableAdapterManager.EconomicClassTableAdapter = Nothing
        Me.TableAdapterManager.HospitalAssignTableAdapter = Nothing
        Me.TableAdapterManager.HospitalTableAdapter = Nothing
        Me.TableAdapterManager.MedicineTableAdapter = Me.MedicineTableAdapter
        Me.TableAdapterManager.PatientTableAdapter = Nothing
        Me.TableAdapterManager.PrescriptionTableAdapter = Me.PrescriptionTableAdapter
        Me.TableAdapterManager.UpdateOrder = ColoradoDiabetesForms.ColoradoDiabetesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'DoctorTableAdapter
        '
        Me.DoctorTableAdapter.ClearBeforeFill = True
        '
        'MedicineTableAdapter
        '
        Me.MedicineTableAdapter.ClearBeforeFill = True
        '
        'PrescriptionBindingNavigator
        '
        Me.PrescriptionBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.PrescriptionBindingNavigator.BindingSource = Me.PrescriptionBindingSource
        Me.PrescriptionBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.PrescriptionBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.PrescriptionBindingNavigator.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.PrescriptionBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.PrescriptionBindingNavigatorSaveItem})
        Me.PrescriptionBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.PrescriptionBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.PrescriptionBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.PrescriptionBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.PrescriptionBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.PrescriptionBindingNavigator.Name = "PrescriptionBindingNavigator"
        Me.PrescriptionBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.PrescriptionBindingNavigator.Size = New System.Drawing.Size(1198, 50)
        Me.PrescriptionBindingNavigator.TabIndex = 0
        Me.PrescriptionBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Enabled = False
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(71, 44)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 50)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 39)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 50)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(46, 44)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 50)
        '
        'PrescriptionBindingNavigatorSaveItem
        '
        Me.PrescriptionBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrescriptionBindingNavigatorSaveItem.Enabled = False
        Me.PrescriptionBindingNavigatorSaveItem.Image = CType(resources.GetObject("PrescriptionBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.PrescriptionBindingNavigatorSaveItem.Name = "PrescriptionBindingNavigatorSaveItem"
        Me.PrescriptionBindingNavigatorSaveItem.Size = New System.Drawing.Size(46, 44)
        Me.PrescriptionBindingNavigatorSaveItem.Text = "Save Data"
        '
        'PrescriptionIDTextBox
        '
        Me.PrescriptionIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PrescriptionBindingSource, "PrescriptionID", True))
        Me.PrescriptionIDTextBox.Location = New System.Drawing.Point(423, 168)
        Me.PrescriptionIDTextBox.Name = "PrescriptionIDTextBox"
        Me.PrescriptionIDTextBox.Size = New System.Drawing.Size(82, 31)
        Me.PrescriptionIDTextBox.TabIndex = 2
        '
        'PrescriptionDescriptionTextBox
        '
        Me.PrescriptionDescriptionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PrescriptionBindingSource, "PrescriptionDescription", True))
        Me.PrescriptionDescriptionTextBox.Location = New System.Drawing.Point(423, 205)
        Me.PrescriptionDescriptionTextBox.Multiline = True
        Me.PrescriptionDescriptionTextBox.Name = "PrescriptionDescriptionTextBox"
        Me.PrescriptionDescriptionTextBox.Size = New System.Drawing.Size(353, 95)
        Me.PrescriptionDescriptionTextBox.TabIndex = 4
        '
        'RefillPerMonthTextBox
        '
        Me.RefillPerMonthTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PrescriptionBindingSource, "RefillPerMonth", True))
        Me.RefillPerMonthTextBox.Location = New System.Drawing.Point(423, 343)
        Me.RefillPerMonthTextBox.Name = "RefillPerMonthTextBox"
        Me.RefillPerMonthTextBox.Size = New System.Drawing.Size(64, 31)
        Me.RefillPerMonthTextBox.TabIndex = 8
        Me.RefillPerMonthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DatePrescribedDateTimePicker
        '
        Me.DatePrescribedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PrescriptionBindingSource, "DatePrescribed", True))
        Me.DatePrescribedDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DatePrescribedDateTimePicker.Location = New System.Drawing.Point(423, 417)
        Me.DatePrescribedDateTimePicker.Name = "DatePrescribedDateTimePicker"
        Me.DatePrescribedDateTimePicker.Size = New System.Drawing.Size(200, 31)
        Me.DatePrescribedDateTimePicker.TabIndex = 12
        '
        'MedicineIDComboBox
        '
        Me.MedicineIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.PrescriptionBindingSource, "MedicineID", True))
        Me.MedicineIDComboBox.DataSource = Me.MedicineBindingSource
        Me.MedicineIDComboBox.DisplayMember = "MedicineName"
        Me.MedicineIDComboBox.FormattingEnabled = True
        Me.MedicineIDComboBox.Location = New System.Drawing.Point(423, 454)
        Me.MedicineIDComboBox.Name = "MedicineIDComboBox"
        Me.MedicineIDComboBox.Size = New System.Drawing.Size(269, 33)
        Me.MedicineIDComboBox.TabIndex = 14
        Me.MedicineIDComboBox.ValueMember = "MedicineID"
        '
        'MedicineBindingSource
        '
        Me.MedicineBindingSource.DataMember = "Medicine"
        Me.MedicineBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'DoctorIDComboBox
        '
        Me.DoctorIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.PrescriptionBindingSource, "DoctorID", True))
        Me.DoctorIDComboBox.DataSource = Me.DoctorBindingSource
        Me.DoctorIDComboBox.DisplayMember = "DoctorFullName"
        Me.DoctorIDComboBox.FormattingEnabled = True
        Me.DoctorIDComboBox.Location = New System.Drawing.Point(423, 493)
        Me.DoctorIDComboBox.Name = "DoctorIDComboBox"
        Me.DoctorIDComboBox.Size = New System.Drawing.Size(241, 33)
        Me.DoctorIDComboBox.TabIndex = 16
        Me.DoctorIDComboBox.ValueMember = "DoctorID"
        '
        'DoctorBindingSource
        '
        Me.DoctorBindingSource.DataMember = "Doctor"
        Me.DoctorBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'PatientIDComboBox
        '
        Me.PatientIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.PrescriptionBindingSource, "PatientID", True))
        Me.PatientIDComboBox.DataSource = Me.PatientBindingSource
        Me.PatientIDComboBox.DisplayMember = "PatientFullName"
        Me.PatientIDComboBox.FormattingEnabled = True
        Me.PatientIDComboBox.Location = New System.Drawing.Point(423, 532)
        Me.PatientIDComboBox.Name = "PatientIDComboBox"
        Me.PatientIDComboBox.Size = New System.Drawing.Size(241, 33)
        Me.PatientIDComboBox.TabIndex = 18
        Me.PatientIDComboBox.ValueMember = "PatientID"
        '
        'PatientBindingSource
        '
        Me.PatientBindingSource.DataMember = "Patient"
        Me.PatientBindingSource.DataSource = Me.ColoradoDiabetesDataSet
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.Location = New System.Drawing.Point(86, 572)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(307, 25)
        Me.lblDiscount.TabIndex = 19
        Me.lblDiscount.Text = "Recommended Discount Price:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ColoradoDiabetesForms.My.Resources.Resources.COFlag
        Me.PictureBox1.Location = New System.Drawing.Point(829, 189)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(301, 164)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'PatientTableAdapter
        '
        Me.PatientTableAdapter.ClearBeforeFill = True
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PrescriptionBindingSource, "PrescriptionCost", True))
        Me.MaskedTextBox1.Location = New System.Drawing.Point(423, 306)
        Me.MaskedTextBox1.Mask = "$000"
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(64, 31)
        Me.MaskedTextBox1.TabIndex = 21
        Me.MaskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DiscountTextBox
        '
        Me.DiscountTextBox.Location = New System.Drawing.Point(423, 572)
        Me.DiscountTextBox.Name = "DiscountTextBox"
        Me.DiscountTextBox.Size = New System.Drawing.Size(127, 31)
        Me.DiscountTextBox.TabIndex = 22
        '
        'MonthlyCostTextBox
        '
        Me.MonthlyCostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PrescriptionBindingSource, "MonthlyCost", True))
        Me.MonthlyCostTextBox.Location = New System.Drawing.Point(423, 380)
        Me.MonthlyCostTextBox.Mask = "$000"
        Me.MonthlyCostTextBox.Name = "MonthlyCostTextBox"
        Me.MonthlyCostTextBox.Size = New System.Drawing.Size(64, 31)
        Me.MonthlyCostTextBox.TabIndex = 23
        Me.MonthlyCostTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrescriptionIDToolStripLabel, Me.PrescriptionIDToolStripTextBox, Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 50)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(1198, 50)
        Me.FillByToolStrip.TabIndex = 24
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'PrescriptionIDToolStripLabel
        '
        Me.PrescriptionIDToolStripLabel.Name = "PrescriptionIDToolStripLabel"
        Me.PrescriptionIDToolStripLabel.Size = New System.Drawing.Size(168, 44)
        Me.PrescriptionIDToolStripLabel.Text = "PrescriptionID:"
        '
        'PrescriptionIDToolStripTextBox
        '
        Me.PrescriptionIDToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.PrescriptionIDToolStripTextBox.Name = "PrescriptionIDToolStripTextBox"
        Me.PrescriptionIDToolStripTextBox.Size = New System.Drawing.Size(100, 50)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(90, 44)
        Me.FillByToolStripButton.Text = "Search"
        '
        'lblTitlePreDet
        '
        Me.lblTitlePreDet.AutoSize = True
        Me.lblTitlePreDet.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitlePreDet.Location = New System.Drawing.Point(462, 122)
        Me.lblTitlePreDet.Name = "lblTitlePreDet"
        Me.lblTitlePreDet.Size = New System.Drawing.Size(314, 31)
        Me.lblTitlePreDet.TabIndex = 25
        Me.lblTitlePreDet.Text = "Precription Detail Form"
        '
        'PatientTableAdapter1
        '
        Me.PatientTableAdapter1.ClearBeforeFill = True
        '
        'PrescriptionDetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(1198, 692)
        Me.Controls.Add(Me.lblTitlePreDet)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.MonthlyCostTextBox)
        Me.Controls.Add(Me.DiscountTextBox)
        Me.Controls.Add(Me.MaskedTextBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblDiscount)
        Me.Controls.Add(PrescriptionIDLabel)
        Me.Controls.Add(Me.PrescriptionIDTextBox)
        Me.Controls.Add(PrescriptionDescriptionLabel)
        Me.Controls.Add(Me.PrescriptionDescriptionTextBox)
        Me.Controls.Add(PrescriptionCostLabel)
        Me.Controls.Add(RefillPerMonthLabel)
        Me.Controls.Add(Me.RefillPerMonthTextBox)
        Me.Controls.Add(MonthlyCostLabel)
        Me.Controls.Add(DatePrescribedLabel)
        Me.Controls.Add(Me.DatePrescribedDateTimePicker)
        Me.Controls.Add(MedicineIDLabel)
        Me.Controls.Add(Me.MedicineIDComboBox)
        Me.Controls.Add(DoctorIDLabel)
        Me.Controls.Add(Me.DoctorIDComboBox)
        Me.Controls.Add(PatientIDLabel)
        Me.Controls.Add(Me.PatientIDComboBox)
        Me.Controls.Add(Me.PrescriptionBindingNavigator)
        Me.Name = "PrescriptionDetail"
        Me.Text = "PrescriptionDetail"
        CType(Me.ColoradoDiabetesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrescriptionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrescriptionBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PrescriptionBindingNavigator.ResumeLayout(False)
        Me.PrescriptionBindingNavigator.PerformLayout()
        CType(Me.MedicineBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ColoradoDiabetesDataSet As ColoradoDiabetesDataSet
    Friend WithEvents PrescriptionBindingSource As BindingSource
    Friend WithEvents PrescriptionTableAdapter As ColoradoDiabetesDataSetTableAdapters.PrescriptionTableAdapter
    Friend WithEvents TableAdapterManager As ColoradoDiabetesDataSetTableAdapters.TableAdapterManager
    Friend WithEvents PrescriptionBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents PrescriptionBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents PrescriptionIDTextBox As TextBox
    Friend WithEvents PrescriptionDescriptionTextBox As TextBox
    Friend WithEvents RefillPerMonthTextBox As TextBox
    Friend WithEvents DatePrescribedDateTimePicker As DateTimePicker
    Friend WithEvents MedicineIDComboBox As ComboBox
    Friend WithEvents DoctorIDComboBox As ComboBox
    Friend WithEvents PatientIDComboBox As ComboBox
    Friend WithEvents lblDiscount As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MedicineTableAdapter As ColoradoDiabetesDataSetTableAdapters.MedicineTableAdapter
    Friend WithEvents MedicineBindingSource As BindingSource
    Friend WithEvents DoctorTableAdapter As ColoradoDiabetesDataSetTableAdapters.DoctorTableAdapter
    Friend WithEvents DoctorBindingSource As BindingSource
    Friend WithEvents PatientBindingSource As BindingSource
    Friend WithEvents PatientTableAdapter As ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter
    Friend WithEvents MaskedTextBox1 As MaskedTextBox
    Friend WithEvents DiscountTextBox As TextBox
    Friend WithEvents MonthlyCostTextBox As MaskedTextBox
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents PrescriptionIDToolStripLabel As ToolStripLabel
    Friend WithEvents PrescriptionIDToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents lblTitlePreDet As Label
    Friend WithEvents PatientTableAdapter1 As ColoradoDiabetesDataSetTableAdapters.PatientTableAdapter
End Class
