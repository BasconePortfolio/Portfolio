-- ColoradoDiabetes view developed and written by Nicholas Bascone
-- Peer Reviewed By: McKayla Sanchez
-- Originally Written: 5/15/2021
-- Last updated: 5/15/2021
------
-- This is a view made to show the Patient's name, diabetes type, and some information about their prescription and cost.
-- This will be used in a search to search by city, diabetes type, and between dates prescribed. 
-- This will help the state find which types of diabetes are common where for a certain range of time.
-- Or to compare if something has changed over time in the data.
------
-- Use the ColoradoDiabetes dataset
USE ColoradoDiabetes
GO
-- Use if exists to make sure that if the view already exists it gets deleted to prevent errors.
IF EXISTS (
		SELECT *
		FROM sys.views
		WHERE NAME = N'PatientDiabetesCost'
		)
		DROP VIEW PatientDiabetesCost;
GO
-- Creating the view with a calculation to get the total cost per month of medicine
-- All the tables are joined to get the results I need below.
CREATE VIEW PatientDiabetesCost
AS
	SELECT Patient.PatientLastName, Patient.PatientFirstName, DiabetesType.DiabetesType, Patient.PatientCityName, Medicine.MedicineName, Prescription.DatePrescribed, Prescription.MonthlyCost
	FROM Patient
	INNER JOIN Prescription
		ON Patient.PatientID = Prescription.PatientID
	INNER JOIN Medicine
		ON Prescription.MedicineID = Medicine.MedicineID
	INNER JOIN Diagnosis
		ON Patient.PatientID = Diagnosis.PatientID
	INNER JOIN DiabetesType
		ON Diagnosis.DiabetesTypeID = DiabetesType.DiabetesTypeID
WITH CHECK OPTION;--Check to make sure there's referential integrity
GO