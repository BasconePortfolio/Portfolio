Read Me made by Nick Bascone on 5/16/2021
Peer Reviewer: McKayla Sanchez

Project Setup:
Step 1:Unzip the file in a place on your laptop you can access the project.

Step 2:For this project is to rebuild Colorado Diabetes. Put the BuildColoradoDiabetes.sql form into SQLServer, don't run it yet.

Step 3:Reroute the data path file to THIS folder, one of the CSV files has been changed to add a new column so please direct it to the unzipped file.

Step 4:Then in SQLServer, please add in the ColoradoDiabetesView.sql file and run it to build the view so that it works in the Colorado Diabetes Forms.

Accessing & Testing Forms:
Step 1:Open the Colorado Diabetes Forms 

Step 2:When you get in you'll be greeted by the Patient Diagnosis SubForm, run this first.
 
Step 3:When you run it, you may need to resize the window that pops up. To test the search button at the top put a 'H%' in and search,
you should get 4 results from the search.

Step 4:Next you should go and change the startup form to the Precription Detail Form. Click the form so that you can see it in the form window.

Step 5:Run the form, you may need to resize the window that pops up. You should see each prescription and extra details in the comboboxes 
with information about the prescription. 

Step 6:To test for the search box, put in an ID number from 1-50 I recommend 7 because it's lucky.
The function (UDF) and purposeful SUB in this form should give you a recommended discount if the Prescription cost matches certain criteria.

Step 7:Next you should go and change the startup form to the EconomicClassDGV. Click the form so that you can see it in the form window.

Step 8:Run the form, you may need to resize the window that pops up. To test the Search query you should be able to type a ID number from 1-50
and get a result, I'd recommend using 7 because it's lucky.

Step 9:Next you should go and change the startup form to PatientSearch. Click the form so that you can see it in the form window.

Step 10:Run the form, you may need to resize the window that pops up. You can keep all default items and press search. You should get 3 results and have 
some calculations at the bottom from another SUB routine to give calculations for total monthly cost of meds, count of patients who fit this criteria,
and an AVG of monthly cost per month. The numbers if run correctly should read, $600, 3, and $200 in order from top to bottom.

Step 11:Go back up to the Search, change the City to Cherry Creek and search again. This time, since no listings exist it should have a pop up message
saying that it couldn't find anything.

Step 12:You have now explored my form! Hopefully it wasn't a dumpster fire!