﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ColoradoDiabetesStartup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblPic = New System.Windows.Forms.Label()
        Me.btnPrescription = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.grpDoc = New System.Windows.Forms.GroupBox()
        Me.btnEconClass = New System.Windows.Forms.Button()
        Me.btnDiagnosis = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDoc.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(1023, 75)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(117, 48)
        Me.btnExit.TabIndex = 37
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(396, 81)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(516, 31)
        Me.lblTitle.TabIndex = 38
        Me.lblTitle.Text = "Colorado Diabetes Information System"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ColoradoDiabetesForms.My.Resources.Resources.COFlag
        Me.PictureBox1.Location = New System.Drawing.Point(122, 72)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(218, 118)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 39
        Me.PictureBox1.TabStop = False
        '
        'lblPic
        '
        Me.lblPic.AutoSize = True
        Me.lblPic.Location = New System.Drawing.Point(135, 193)
        Me.lblPic.Name = "lblPic"
        Me.lblPic.Size = New System.Drawing.Size(190, 25)
        Me.lblPic.TabIndex = 40
        Me.lblPic.Text = "Colorado Diabetes"
        '
        'btnPrescription
        '
        Me.btnPrescription.Location = New System.Drawing.Point(61, 176)
        Me.btnPrescription.Name = "btnPrescription"
        Me.btnPrescription.Size = New System.Drawing.Size(214, 49)
        Me.btnPrescription.TabIndex = 41
        Me.btnPrescription.Text = "Prescription Detail"
        Me.btnPrescription.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(61, 68)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(214, 49)
        Me.btnSearch.TabIndex = 42
        Me.btnSearch.Text = "Patient Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'grpDoc
        '
        Me.grpDoc.Controls.Add(Me.btnPrescription)
        Me.grpDoc.Controls.Add(Me.btnSearch)
        Me.grpDoc.Location = New System.Drawing.Point(210, 334)
        Me.grpDoc.Name = "grpDoc"
        Me.grpDoc.Size = New System.Drawing.Size(337, 283)
        Me.grpDoc.TabIndex = 43
        Me.grpDoc.TabStop = False
        Me.grpDoc.Text = "Forms"
        '
        'btnEconClass
        '
        Me.btnEconClass.Location = New System.Drawing.Point(61, 176)
        Me.btnEconClass.Name = "btnEconClass"
        Me.btnEconClass.Size = New System.Drawing.Size(214, 49)
        Me.btnEconClass.TabIndex = 44
        Me.btnEconClass.Text = "Economic Class"
        Me.btnEconClass.UseVisualStyleBackColor = True
        '
        'btnDiagnosis
        '
        Me.btnDiagnosis.Location = New System.Drawing.Point(61, 68)
        Me.btnDiagnosis.Name = "btnDiagnosis"
        Me.btnDiagnosis.Size = New System.Drawing.Size(214, 49)
        Me.btnDiagnosis.TabIndex = 45
        Me.btnDiagnosis.Text = "Patient Diagnosis"
        Me.btnDiagnosis.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnDiagnosis)
        Me.GroupBox1.Controls.Add(Me.btnEconClass)
        Me.GroupBox1.Location = New System.Drawing.Point(757, 334)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(325, 283)
        Me.GroupBox1.TabIndex = 46
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Forms"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(229, 275)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(300, 29)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "CO Doctors and Officials"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(841, 275)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 29)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "CO Officials"
        '
        'ColoradoDiabetesStartup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(1316, 758)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpDoc)
        Me.Controls.Add(Me.lblPic)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "ColoradoDiabetesStartup"
        Me.Text = "ColoradoDiabetesStartup"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDoc.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblTitle As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblPic As Label
    Friend WithEvents btnPrescription As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents grpDoc As GroupBox
    Friend WithEvents btnEconClass As Button
    Friend WithEvents btnDiagnosis As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
