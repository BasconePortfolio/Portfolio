﻿Public Class ColoradoDiabetesStartup
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            Dim frmSearch As New PatientSearch
            frmSearch.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnPrescription_Click(sender As Object, e As EventArgs) Handles btnPrescription.Click
        Try
            Dim frmPrescription As New PrescriptionDetail
            frmPrescription.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnDiagnosis_Click(sender As Object, e As EventArgs) Handles btnDiagnosis.Click
        Try
            Dim frmDiagnosis As New PatientDiagnosis
            frmDiagnosis.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnEconClass_Click(sender As Object, e As EventArgs) Handles btnEconClass.Click
        Try
            Dim frmEconClass As New EconomicClassDGV
            frmEconClass.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class