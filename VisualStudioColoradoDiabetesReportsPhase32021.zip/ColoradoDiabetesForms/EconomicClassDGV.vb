﻿Public Class EconomicClassDGV
    Private Sub EconomicClassAssignBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles EconomicClassAssignBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.EconomicClassAssignBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ColoradoDiabetesDataSet)

    End Sub

    Private Sub EconomicClassDGV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.EconomicClass' table. You can move, or remove it, as needed.
        Me.EconomicClassTableAdapter.Fill(Me.ColoradoDiabetesDataSet.EconomicClass)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Patient)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.EconomicClassAssign' table. You can move, or remove it, as needed.
        Me.EconomicClassAssignTableAdapter.Fill(Me.ColoradoDiabetesDataSet.EconomicClassAssign)

    End Sub
    Private Sub EconClassDGV_Closing(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        EconomicClassAssignBindingSource.Dispose()

        EconomicClassAssignDataGridView.Dispose()

    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.EconomicClassAssignTableAdapter.FillBy(Me.ColoradoDiabetesDataSet.EconomicClassAssign, CType(EconomicClassAssignIDToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class