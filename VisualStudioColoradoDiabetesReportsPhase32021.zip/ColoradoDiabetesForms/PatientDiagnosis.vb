﻿Public Class PatientDiagnosis
    Private Sub PatientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles PatientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PatientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ColoradoDiabetesDataSet)

    End Sub

    Private Sub PatientDiagnosis_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.DiabetesType' table. You can move, or remove it, as needed.
        Me.DiabetesTypeTableAdapter.Fill(Me.ColoradoDiabetesDataSet.DiabetesType)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Diagnosis' table. You can move, or remove it, as needed.
        Me.DiagnosisTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Diagnosis)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Patient)

    End Sub
    Private Sub Diagnosis_Closing(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        DiagnosisBindingSource.Dispose()

        DiagnosisDataGridView.Dispose()

    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.PatientTableAdapter.FillBy(Me.ColoradoDiabetesDataSet.Patient, PatientLastNameToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class