﻿Public Class PrescriptionDetail
    Private Sub PrescriptionBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles PrescriptionBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PrescriptionBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ColoradoDiabetesDataSet)

    End Sub

    Private Sub PrescriptionDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Patient)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Doctor' table. You can move, or remove it, as needed.
        Me.DoctorTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Doctor)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Medicine' table. You can move, or remove it, as needed.
        Me.MedicineTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Medicine)
        'TODO: This line of code loads data into the 'ColoradoDiabetesDataSet.Prescription' table. You can move, or remove it, as needed.
        Me.PrescriptionTableAdapter.Fill(Me.ColoradoDiabetesDataSet.Prescription)
        CopayCalc()
    End Sub
    Private Function PatientDiscount(ByVal amount As Decimal) As Decimal
        Dim discount As Decimal
        If amount >= 300 Then
            discount = 0.85
        ElseIf amount >= 250 Then
            discount = 0.9
        ElseIf amount >= 200 Then
            discount = 0.95
        ElseIf amount < 200 Then
            discount = 1
        End If
        Return discount
    End Function
    Private Sub CopayCalc()
        Try
            'For Each rowView As DataRowView In Me.PrescriptionBindingSource
            'Dim row = rowView.Row
            Dim discount As Decimal
            Dim Newtotal As Decimal
            discount = PatientDiscount(CType(Me.MonthlyCostTextBox.Text, Decimal))
            'If (discount <> CType(Me.MonthlyCostTextBox.Text, Decimal)) Then
            Dim Cost As Decimal = (CType(Me.MonthlyCostTextBox.Text, Decimal))
            Newtotal = discount * Cost
            'End If
            DiscountTextBox.Text = Newtotal.ToString("$ #,0.00")
            'Next rowView
            'Me.PrescriptionBindingSource.ResetBindings(False)
        Catch ex As Exception
            MsgBox(ex.Message, , "Unexpected Error")
        End Try
    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.PrescriptionTableAdapter.FillBy(Me.ColoradoDiabetesDataSet.Prescription, CType(PrescriptionIDToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BindingNavigatorMoveNextItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorMoveNextItem.Click
        CopayCalc()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    'Private Sub PrescriptionBindingSource_CurrentChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrescriptionBindingSource.CurrentChanged
    'CopayCalc()
    'End Sub


End Class
