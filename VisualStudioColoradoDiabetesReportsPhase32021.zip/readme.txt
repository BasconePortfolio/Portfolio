Read Me made by Nick Bascone on 6/6/2021
Peer Reviewer: McKayla Sanchez

Project Setup:
Step 1:Unzip the file in a place on your laptop you can access the project. Good news, there is not need to update the ColoradoDiabetes Database or 
any of the build code.

Accessing & Testing Forms:
Step 1:Open the Colorado Diabetes Forms 

Step 2:When you get in you'll be greeted by the ColoradoDiabetesStartup form, run this first.

Step 3: Click on the Patient Search button to take you to the Patient Search Table

Step 4: Run the form, you may need to resize the window that pops up. You can keep all default items and press search. You should get 3 results and have 
some calculations at the bottom from another SUB routine to give calculations for total monthly cost of meds, count of patients who fit this criteria,
and an AVG of monthly cost per month. The numbers if run correctly should read, $600, 3, and $200 in order from top to bottom.
 
Step 5:Go back up to the Search, change the City to Cherry Creek and search again. This time, since no listings exist it should have a pop up message
saying that it couldn't find anything. Press the Exit button to go back to the startup file.

Step 6: Click on the Prescription Detail button to take you to the form

Step 7:Run the form, you may need to resize the window that pops up. You should see each prescription and extra details in the comboboxes 
with information about the prescription. 

Step 8:To test for the search box, put in an ID number from 1-50 I recommend 7 because it's lucky.
The function (UDF) and purposeful SUB in this form should give you a recommended discount if the Prescription cost matches certain criteria.
Press the Exit button to go back to the startup file.

Step 9: Click on the Patient Diagnosis button to take you to the form

Step 10:When you run it, you may need to resize the window that pops up. To test the search button at the top put a 'H%' in and search,
you should get 4 results from the search. Press the Exit button to go back to the startup file.

Step 11: Click on the Economic Class button to take you to the form

Step 12:Run the form, you may need to resize the window that pops up. To test the Search query you should be able to type a ID number from 1-50
and get a result, I'd recommend using 7 because it's lucky. Press the Exit button to go back to the startup file.

Step 13: Use the Exit button to get out of the startup form and click open the Medicine Cost by Year and City report.

Step 14: Open it up in preview mode. The default diabetes type filter for the report should be Type1, but you can change it to any type you want to test 
whether the parameter works. Do back into design mode before moving on.

Step 15: Next, open up the Doctor Information Report. Go into preview mode and click the drilldown Hospital City Name Aurora, and Hospital Name Kindred 
Hospital to show the best example of Doctor data. Go back into design mode.

Step 12:You have now explored my final project! Hopefully it wasn't a dumpster fire!